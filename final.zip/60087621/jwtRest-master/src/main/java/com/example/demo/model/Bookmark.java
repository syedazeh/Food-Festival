package com.example.demo.model;

import javax.persistence.*;

@Entity
public class Bookmark {
    private long id;
    private long eventid;
    private String userid;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "EVENTID")
    public long getEventid() {
        return eventid;
    }

    public void setEventid(long eventid) {
        this.eventid = eventid;
    }

    @Basic
    @Column(name = "USERID")
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Bookmark bookmark = (Bookmark) o;

        if (id != bookmark.id) return false;
        if (eventid != bookmark.eventid) return false;
        if (userid != null ? !userid.equals(bookmark.userid) : bookmark.userid != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) (id ^ (id >>> 32));
        result = 31 * result + (int) (eventid ^ (eventid >>> 32));
        result = 31 * result + (userid != null ? userid.hashCode() : 0);
        return result;
    }
}
