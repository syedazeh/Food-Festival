package com.example.demo.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Foodeventplot {
    private Long id;
    private long eventid;
    private long foodCompanyid;
    private long plotid;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "EVENTID")
    public long getEventid() {
        return eventid;
    }

    public void setEventid(long eventid) {
        this.eventid = eventid;
    }

    @Basic
    @Column(name = "FOOD_COMPANYID")
    public long getFoodCompanyid() {
        return foodCompanyid;
    }

    public void setFoodCompanyid(long foodCompanyid) {
        this.foodCompanyid = foodCompanyid;
    }

    @Basic
    @Column(name = "PLOTID")
    public long getPlotid() {
        return plotid;
    }

    public void setPlotid(long plotid) {
        this.plotid = plotid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Foodeventplot that = (Foodeventplot) o;
        return eventid == that.eventid && foodCompanyid == that.foodCompanyid && plotid == that.plotid && Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, eventid, foodCompanyid, plotid);
    }
}
