package com.example.demo.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Promotion {
    private Long id;
    private long eventid;
    private String type;
    private String description;
    private Integer promotioncode;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "EVENTID")
    public long getEventid() {
        return eventid;
    }

    public void setEventid(long eventid) {
        this.eventid = eventid;
    }

    @Basic
    @Column(name = "TYPE")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Basic
    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "PROMOTIONCODE")
    public Integer getPromotioncode() {
        return promotioncode;
    }

    public void setPromotioncode(Integer promotioncode) {
        this.promotioncode = promotioncode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Promotion promotion = (Promotion) o;
        return eventid == promotion.eventid && Objects.equals(id, promotion.id) && Objects.equals(type, promotion.type) && Objects.equals(description, promotion.description) && Objects.equals(promotioncode, promotion.promotioncode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, eventid, type, description, promotioncode);
    }
}
