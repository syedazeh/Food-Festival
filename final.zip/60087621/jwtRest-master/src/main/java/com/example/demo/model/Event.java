package com.example.demo.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
public class Event {
    private Long id;
    private Long sponsorpartnerid;
    private String name;
    private String type;
    private Timestamp startdate;
    private Timestamp enddate;
    private String status;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "SPONSORPARTNERID")
    public Long getSponsorpartnerid() {
        return sponsorpartnerid;
    }

    public void setSponsorpartnerid(Long sponsorpartnerid) {
        this.sponsorpartnerid = sponsorpartnerid;
    }

    @Basic
    @Column(name = "NAME")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "TYPE")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Basic
    @Column(name = "STARTDATE")
    public Timestamp getStartdate() {
        return startdate;
    }

    public void setStartdate(Timestamp startdate) {
        this.startdate = startdate;
    }

    @Basic
    @Column(name = "ENDDATE")
    public Timestamp getEnddate() {
        return enddate;
    }

    public void setEnddate(Timestamp enddate) {
        this.enddate = enddate;
    }

    @Basic
    @Column(name = "STATUS")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Event event = (Event) o;
        return Objects.equals(id, event.id) && Objects.equals(sponsorpartnerid, event.sponsorpartnerid) && Objects.equals(name, event.name) && Objects.equals(type, event.type) && Objects.equals(startdate, event.startdate) && Objects.equals(enddate, event.enddate) && Objects.equals(status, event.status);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, sponsorpartnerid, name, type, startdate, enddate, status);
    }
}
