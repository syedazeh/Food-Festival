package com.example.demo.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Plot {
    private Long id;
    private String layout;
    private Integer squarefoot;
    private Integer price;
    private String availability;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "LAYOUT")
    public String getLayout() {
        return layout;
    }

    public void setLayout(String layout) {
        this.layout = layout;
    }

    @Basic
    @Column(name = "SQUAREFOOT")
    public Integer getSquarefoot() {
        return squarefoot;
    }

    public void setSquarefoot(Integer squarefoot) {
        this.squarefoot = squarefoot;
    }

    @Basic
    @Column(name = "PRICE")
    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    @Basic
    @Column(name = "AVAILABILITY")
    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Plot plot = (Plot) o;
        return Objects.equals(id, plot.id) && Objects.equals(layout, plot.layout) && Objects.equals(squarefoot, plot.squarefoot) && Objects.equals(price, plot.price) && Objects.equals(availability, plot.availability);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, layout, squarefoot, price, availability);
    }
}
