package com.example.demo.repository;

import com.example.demo.model.Foodcompany;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FoodcompanyRepository extends JpaRepository<Foodcompany, Long> {
}