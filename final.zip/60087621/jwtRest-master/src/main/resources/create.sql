drop table BOOKMARK if exists;
drop table RATING if exists;
drop table FAQ if exists;
drop table NOTIFICATION if exists;
drop table PROMOTION if exists;
drop table FOODEVENTPLOT if exists;
drop table POPULARSEARCHE if exists;
drop table MEMBERSHIP if exists;
drop table PLOT if exists;
drop table FOODCOMPANY if exists;

drop table CARTITEM if exists;
drop table CART if exists;
drop table USER if exists ;
drop table PRODUCT if exists;

drop table CATEGORY if exists;
drop table DISCOUNT if exists;
drop table EVENT if exists;
drop table SPONSORPARTNER if exists;

-- ID field value will match jwtUser username 1-1
CREATE TABLE USER
(
    ID    VARCHAR(255) not null primary key,
    NAME  VARCHAR(255) not null,
    ROLE  VARCHAR(255) not null,
    PICTURE VARCHAR(255) not null
);

insert into USER (ID, NAME, ROLE, PICTURE) VALUES ('joe@joe.com', 'Joe', 'Customer', '');
insert into USER (ID, NAME, ROLE, PICTURE) VALUES ('ann@ann.com', 'Ann', 'Company-Rep', '');
insert into USER (ID, NAME, ROLE, PICTURE) VALUES ('fred@fred.com', 'Fred', 'Support', '');
insert into USER (ID, NAME, ROLE, PICTURE) VALUES ('admin@admin.com', 'Admin', 'Admin', '');

create table DISCOUNT
(
    ID    BIGINT       not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    NAME         VARCHAR(255),
    CODE         VARCHAR(255),
    VALIDITY     TIMESTAMP
);

--DATE 'YYYY-MM-DD'

insert into DISCOUNT (NAME, CODE, VALIDITY) values ('Standard ticket discount', 'ST100', DATE '1999-04-12');
insert into DISCOUNT (NAME, CODE, VALIDITY) values ('VIP ticket discount', 'VT200', DATE '2021-04-07');
insert into DISCOUNT (NAME, CODE, VALIDITY) values ('Ladies night ticket discount', 'LNT70', DATE '2020-04-27');

create table CATEGORY
(
    ID BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    NAME         VARCHAR(255),
    TYPE         VARCHAR(255)
);

insert into CATEGORY (NAME, TYPE) values ('Thursday Night Ticket', 'Standard Ticket');
insert into CATEGORY (NAME, TYPE) values ('Friday Night Ticket', 'VIP Ticket');
insert into CATEGORY (NAME, TYPE) values ('Saturday Night Ticket', 'Ladies Night Ticket');

create table SPONSORPARTNER
(
    ID BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    TYPE             VARCHAR(255),
    VENUEADDRESS     VARCHAR(255),
    CONTACTNAME      VARCHAR(255),
    VENUENAME        VARCHAR(255),
    EMAIL            VARCHAR(255),
    PHONE            VARCHAR(255)
);

insert into SPONSORPARTNER (TYPE, VENUEADDRESS, CONTACTNAME, VENUENAME, EMAIL, PHONE) VALUES ('Sponsor', 'Cameo House 13-17 Bear Street Leicester Square London, WC2H 7AS', 'Fiji Water', 'Cameo House', 'fijiwater@fijiwater.com', '+44 0203 286 0816');
insert into SPONSORPARTNER (TYPE, VENUEADDRESS, CONTACTNAME, VENUENAME, EMAIL, PHONE) VALUES ('Partner', 'Single Business Tower, 34th Floor, Business Bay, Dubai – UAE', 'Talabat', 'Business Bay', 'info.uae@talabat.com', '+971 4 5906555');
insert into SPONSORPARTNER (TYPE, VENUEADDRESS, CONTACTNAME, VENUENAME, EMAIL, PHONE) VALUES ('Sponsor', 'M Floor, 54 – 54 Al Zainab Rd – Doha, Al Gurg Unilever (AGU) Office', 'Omo', 'Al Gurg Unilever (AGU) Office', 'Kartikey.mishra@unilever.com', '0501686814');

create table EVENT
(
    ID                BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    SPONSORPARTNERID   BIGINT REFERENCES SPONSORPARTNER (ID),
    NAME              VARCHAR(255),
    TYPE              VARCHAR(255),
    STARTDATE         TIMESTAMP,
    ENDDATE           TIMESTAMP,
    STATUS            VARCHAR(255)
);

insert into EVENT (SPONSORPARTNERID, NAME, TYPE, STARTDATE, ENDDATE, STATUS) VALUES (2, 'Chef"s Cookout Challenge', 'Competition', DATE '2021-04-01', DATE '2021-04-08', 'Coming Soon');
insert into EVENT (SPONSORPARTNERID, NAME, TYPE, STARTDATE, ENDDATE, STATUS) VALUES (3, 'Aerobics Circus', 'Entertainment', DATE '2021-03-01', DATE '2021-03-08', 'Ended');
insert into EVENT (SPONSORPARTNERID, NAME, TYPE, STARTDATE, ENDDATE, STATUS) VALUES (2, 'Live Cooking Theatre', 'Educational', DATE '2021-04-12', DATE '2021-04-29', 'Ongoing');

CREATE TABLE PRODUCT
(
    ID    BIGINT       not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    NAME  VARCHAR(255) not null,
    PRICE BIGINT       not null,
    CATEGORYID BIGINT not null REFERENCES CATEGORY (ID),
    DISCOUNTID BIGINT not null REFERENCES DISCOUNT (ID),
    EVENTID    BIGINT not null REFERENCES EVENT (ID)
);

insert into PRODUCT (NAME, PRICE, CATEGORYID, DISCOUNTID, EVENTID) VALUES ('Standard Ticket', 100, 1, 1, 1);
insert into PRODUCT (NAME, PRICE, CATEGORYID, DISCOUNTID, EVENTID) VALUES ('VIP Ticket', 200, 2, 2, 2);
insert into PRODUCT (NAME, PRICE, CATEGORYID, DISCOUNTID, EVENTID) VALUES ('Ladies Night Ticket', 70, 3, 3, 3);

CREATE TABLE CART
(
    ID     BIGINT       not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    STATUS VARCHAR(255) not null,
    USERID VARCHAR(255) not null REFERENCES USER (ID)
);

insert into CART (STATUS, USERID) values ('Paid', 'joe@joe.com');
insert into CART (STATUS, USERID) values ('Paid', 'ann@ann.com');
insert into CART (STATUS, USERID) values ('Paid', 'fred@fred.com');


CREATE TABLE CARTITEM
(
    ID        BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    QUANTITY  INT    not null,
    CARTID    BIGINT not null REFERENCES CART (ID),
    PRODUCTID BIGINT not null REFERENCES PRODUCT (ID)
);

insert into CARTITEM (QUANTITY, CARTID, PRODUCTID) values (1, 1, 1);
insert into CARTITEM (QUANTITY, CARTID, PRODUCTID) values (1, 2, 2);
insert into CARTITEM (QUANTITY, CARTID, PRODUCTID) values (1, 3, 3);

create table FOODCOMPANY
(
    ID             BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    NAME           VARCHAR(255),
    ADDRESS        VARCHAR(255),
    WEBSITE        VARCHAR(255),
    POSITION       VARCHAR(255),
    PHONE          BIGINT,
    EMAIL          VARCHAR(255)
);

insert into FOODCOMPANY (NAME, ADDRESS, WEBSITE, POSITION, PHONE, EMAIL) values ('Baladna', 'AlKhour', 'www.Baladna.com', '', 0097467394735, 'Baladna.gmail.com');
insert into FOODCOMPANY (NAME, ADDRESS, WEBSITE, POSITION, PHONE, EMAIL) values ('Almeera', 'AlRayan', 'www.Almeera.com', '', 0097455456589, 'Almeera.gmail.com');
insert into FOODCOMPANY (NAME, ADDRESS, WEBSITE, POSITION, PHONE, EMAIL) values ('Carefour', 'AlShomal', 'www.Carefour.com', '', 0097465896589, 'Carefour.gmail.com');

create table PLOT
(
    ID           BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    LAYOUT       VARCHAR(255),
    SQUAREFOOT   INTEGER,
    PRICE        INTEGER,
    AVAILABILITY VARCHAR(50)
);

insert into PLOT (LAYOUT, SQUAREFOOT, PRICE, AVAILABILITY) values ('', 100, 2000, 'Available');
insert into PLOT (LAYOUT, SQUAREFOOT, PRICE, AVAILABILITY) values ('', 100, 2000, 'Not Available');
insert into PLOT (LAYOUT, SQUAREFOOT, PRICE, AVAILABILITY) values ('', 100, 2000, 'Available');

create table MEMBERSHIP
(
    ID          BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    NAME        VARCHAR(255),
    TYPE        VARCHAR(255),
    DESCRIPTION VARCHAR(255),
    PRICE       INTEGER,
    VALIDITY    TIMESTAMP
);

insert into MEMBERSHIP (NAME, TYPE, DESCRIPTION, PRICE, VALIDITY) values ('Mahmoud', 'VIP', 'One year membership', 50, DATE '2022-02-23');
insert into MEMBERSHIP (NAME, TYPE, DESCRIPTION, PRICE, VALIDITY) values ('Turki', 'Gold', 'Six month membership', 50, DATE '2022-02-23');
insert into MEMBERSHIP (NAME, TYPE, DESCRIPTION, PRICE, VALIDITY) values ('Ismail', 'VIP', 'One year membership', 50, DATE '2022-08-23');

create table POPULARSEARCHE
(
    ID BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    TITLE             VARCHAR(255),
    FREQUENCY         INTEGER
);

insert into POPULARSEARCHE (TITLE, FREQUENCY) values ('More than 100 searches', 50);
insert into POPULARSEARCHE (TITLE, FREQUENCY) values ('More than 200 searches', 100);
insert into POPULARSEARCHE (TITLE, FREQUENCY) values ('More than 300 searches', 200);

create table FOODEVENTPLOT
(
    ID              BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    EVENTID         BIGINT not null REFERENCES EVENT (ID),
    FOOD_COMPANYID  BIGINT not null REFERENCES FOODCOMPANY (ID),
    PLOTID          BIGINT not null REFERENCES PLOT  (ID)
);

insert into FOODEVENTPLOT (EVENTID, FOOD_COMPANYID, PLOTID) values (1, 1, 1);
insert into FOODEVENTPLOT (EVENTID, FOOD_COMPANYID, PLOTID) values (2, 2, 2);
insert into FOODEVENTPLOT (EVENTID, FOOD_COMPANYID, PLOTID) values (3, 3, 3);

create table PROMOTION
(
    ID              BIGINT not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    EVENTID       BIGINT not null REFERENCES EVENT (ID),
    TYPE            VARCHAR(255),
    DESCRIPTION     VARCHAR(255),
    PROMOTIONCODE   INTEGER
);

insert into PROMOTION (EVENTID, TYPE, DESCRIPTION, PROMOTIONCODE) values (1, 'Gold', 'three Tickets for the price of one', 232425);
insert into PROMOTION (EVENTID, TYPE, DESCRIPTION, PROMOTIONCODE) values (2, 'Silver', 'two tickets in price of one', 252627);
insert into PROMOTION (EVENTID, TYPE, DESCRIPTION, PROMOTIONCODE) values (3, 'Gold', 'three Tickets for the price of one', 242526);

create table NOTIFICATION
(
    ID          BIGINT         not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    USERID      VARCHAR  (255) not null REFERENCES USER (ID),
    EVENTID     BIGINT         not null REFERENCES EVENT (ID),
    TYPE        VARCHAR(255),
    DESCRIPTION VARCHAR(255)
);

insert into NOTIFICATION (USERID, EVENTID, TYPE, DESCRIPTION) values ('joe@joe.com', 1, 'Competition', 'Chinese food festival event taking place in 2days');
insert into NOTIFICATION (USERID, EVENTID, TYPE, DESCRIPTION) values ('ann@ann.com', 1, 'Entertainment', 'Italian food festival event taking place in 7days');
insert into NOTIFICATION (USERID, EVENTID, TYPE, DESCRIPTION) values ('fred@fred.com', 1, 'Educational', 'Fastfood festival event taking place in 4days');

create table FAQ
(
    ID         BIGINT        not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    USERID     VARCHAR (255) not null REFERENCES USER (ID),
    QUESTION   VARCHAR(255),
    ANSWER     VARCHAR(255)
);

insert into FAQ (USERID, QUESTION, ANSWER) values ('admin@admin.com', 'How to check the event dates?', 'The event dates can be checked in event page or the users can get notifications about the date of the events.');
insert into FAQ (USERID, QUESTION, ANSWER) values ('admin@admin.com', 'Where to purchase tickets', 'On ticket page, people can purchase tickets.');
insert into FAQ (USERID, QUESTION, ANSWER) values ('admin@admin.com', 'How to register as a user?', 'on the main page, people have the opportunity to register as new users or log in as existing users.');

create table RATING
(
    ID         BIGINT       not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    USERID     VARCHAR(255) not null REFERENCES USER (ID),
    EVENTID    BIGINT       not null REFERENCES EVENT (ID),
    COMMENT    VARCHAR(255),
    DATE       TIMESTAMP,
    STARS      BIGINT
);

insert into RATING (USERID, EVENTID, COMMENT, DATE, STARS) values ('joe@joe.com', 1, 'This event was very good', DATE '2021-08-25', 3);
insert into RATING (USERID, EVENTID, COMMENT, DATE, STARS) values ('ann@ann.com', 2, 'The events timing is perfect', DATE '2021-09-24', 4);
insert into RATING (USERID, EVENTID, COMMENT, DATE, STARS) values ('fred@fred.com', 3, 'I was able to try new foods that i didnt had the opportunity before', DATE '2021-10-26', 5);

create table BOOKMARK
(
    ID         BIGINT         not null primary key GENERATED ALWAYS AS IDENTITY (START WITH 1),
    EVENTID  BIGINT         not null REFERENCES EVENT (ID),
    USERID     VARCHAR(255)   not null REFERENCES USER (ID)
);

insert into BOOKMARK (EVENTID, USERID) values (1, 'ann@ann.com');
insert into BOOKMARK (EVENTID, USERID) values (2, 'fred@fred.com');
insert into BOOKMARK (EVENTID, USERID) values (3, 'fred@fred.com');
