// const calculateAge = birthdate =>
//     Math.floor((new Date().getTime() - birthdate.getTime()) / (1000 * 60 * 60 * 24 * 365.25))

// const toJavaString = date => {
//     // console.log('date', date)
//     return date.toISOString().replace('T', ' ').replace('Z', '')
// }

const getJwtUser = () => sessionStorage.getItem("jwtUser") ? JSON.parse(sessionStorage.getItem("jwtUser")) : null
const setJwtUser = user => user ? sessionStorage.setItem("jwtUser", JSON.stringify(user)) : sessionStorage.removeItem("jwtUser")

const authFetch = (url, options) => {
    const jwtUser = getJwtUser()
    if (jwtUser) {
        options = options || {}
        options.headers = options.headers || {}
        options.headers.Authorization = `Bearer ${jwtUser.token}`
    }
    return fetch(url, options)
}

const uploadImage = async (imageFile, name) => {
    console.log('imageFile object', imageFile)
    const body = new FormData()
    body.append('file', imageFile, name)
    const result = await authFetch('/images', {
        method: 'POST',
        body
    })
    console.log('uploadImage result', result)
    return result
}

const email = async (to, subject, text) => {
    const result = await fetch('/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to, subject, text })
    })
    console.log('email result', result)
    return result
}

class DB {

    constructor(table) {
        this.table = table
    }


    async create(set, item) {
        console.log(item)
        // const response = 
        await authFetch(`/${this.table}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(item)
            }
        )
        // console.log('create response', response)
        set(await this.findAll())
    }

    async remove(set, id) {
        // const response = 
        await authFetch(`/${this.table}/${id}`,
            {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' }
            }
        )
        // console.log('response', response)
        set(await this.findAll())
    }

    async update(set, item) {
        // const response = 
        await authFetch(`/${this.table}/${item.id}`,
            {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(item)
            }
        )
        // console.log('response', response)
        set(await this.findAll())
    }

    reformatOne(item) {
        // console.log('reformatOne in', item)
        if (item) {
            const { _links, ...rest } = item
            const id = _links.self.href.split(`${this.table}/`)[1]
            item = { id, ...rest }
            // console.log('reformatOne out', item)
        }
        return item
    }

    reformatAll(items) {
        // console.log('reformatAll in', items)
        items = items._embedded[this.table].map(item => this.reformatOne(item))
        // console.log('reformatAll out', items)
        return items
    }

    async find(query) {
        // access the server through url, issuing GET request
        // for url: http://localhost:8080/registers (for example)
        const response = await authFetch(`/${this.table}/${query}`,
            {
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        )
        // console.log('response', response)
        if (response.ok) {
            const json = await response.json()
            // console.log('json', json)
            return json
        }
        else {
            return undefined
        }
    }

    async findAll() {
        return this.reformatAll(await this.find(""))
    }

    async findOne(id) {
        return this.reformatOne(await this.find(id))
    }
}

class Users extends DB {

    constructor() {
        super("users")
    }
    async findOne(id) {
        return this.reformatOne(await this.find(id))
    }
}

class Products extends DB {

    constructor() {
        super("products")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }

    async findByNameContaining(name) {
        return this.reformatAll(await this.find(`search/findByNameContaining?name=${name}`))
    }

    async findByCategoryid(id) {
        return this.reformatAll(await this.find(`search/findByCategoryid?id=${id}`))
    }

    async findByDiscountid(id) {
        return this.reformatAll(await this.find(`search/findByDiscountid?id=${id}`))
    }
    async findOne(id) {
        return this.reformatOne(await this.find(id))
    }

}

class Carts extends DB {

    constructor() {
        super("carts")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
    async findCartByUseridAndStatus(id,status){
        return this.reformatAll(await this.find(`search/findCartByUseridAndStatus?id=${id}&status=${status}`))
    }

    async findByUseridAndStatus(id,status){
        return this.reformatAll(await this.find(`search/findByUseridAndStatus?id=${id}&status=${status}`))
    }
}

class Cartitems extends DB {

    constructor() {
        super("cartitems")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }

    async findByProductid(id) {
        return this.reformatAll(await this.find(`search/findByProductid?id=${id}`))
    }

    async findByCartid(id){
        return this.reformatAll(await this.find(`search/findByCartid?id=${id}`))
    }

}

class Events extends DB{
    constructor(){
        super("events")
    }
    async findOne(id) {
        return this.reformatOne(await this.find(id))
    }
    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id, startdate: new Date(item.startdate), enddate: new Date(item.enddate) }
        return item
    }

    async findEventById(id) {
        return this.reformatAll(await this.find(`search/findEventById?id=${id}`))
    }
    async findByNameContaining(name) {
        return this.reformatAll(await this.find(`search/findByNameContaining?name=${name}`))
    }
}

class FoodCompanies extends DB{
    constructor(){
        super("foodcompanies")
    }
    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class FoodEventPlot extends DB{
    constructor(){
        super("foodeventplots")
    }
    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class Plots extends DB{
    constructor(){
        super("plots")
    }
    
    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class Categories extends DB{
    constructor(){
        super("categories")
    }

    async findCategoryById(id) {
        return this.reformatAll(await this.find(`search/findCategoryById?id=${id}`))
    }
    
}

class PopularSearches extends DB {
    constructor() {
        super("popularsearches")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class SponsorPartners extends DB {

    constructor() {
        super("sponsorpartners")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }

    // async findBySponsorid(id) {
    //     return this.reformatAll(await this.find(`search/findBySponsorid?id=${id}`))    
    // }

    
    async findByNameContaining(name) {
        return this.reformatAll(await this.find(`search/findByNameContaining?name=${name}`))
    }
}

class Discounts extends DB{
    constructor(){
        super("discounts")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id, validity: new Date(item.validity) }
        return item
    }

    async findByCode(id) {
        return this.reformatAll(await this.find(`search/findByCode?id=${id}`))
    }

    async findDiscountById(id) {
        return this.reformatAll(await this.find(`search/findDiscountById?id=${id}`))
    }
    

}

class Bookmarks extends DB{
    constructor(){
        super("bookmarks")
    }
    async findOne(id) {
        return this.reformatOne(await this.find(id))
    }
    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class Ratings extends DB{
    constructor(){
        super("ratings")
    }
    async findOne(id) {
        return this.reformatOne(await this.find(id))
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id, date: new Date(item.date) }
        return item
    }
}

class Memberships extends DB {
    constructor() {
        super("memberships")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class Promotions extends DB {

    constructor() {
        super("promotions")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class Notifications extends DB {
    constructor() {
        super("notifications")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }
}

class Faqs extends DB {
    constructor() {
        super("faqs")
    }

    reformatOne(item) {
        item = super.reformatOne(item)
        item = { ...item, id: 1 * item.id }
        return item
    }

    async findByNameContaining(question) {
        return this.reformatAll(await this.find(`search/findByNameContaining?question=${question}`))
    }
}

const db = {
    getJwtUser,
    setJwtUser,
    uploadImage,
    email,
    Products: new Products(),
    Users: new Users(),
    Carts: new Carts(),
    Cartitems: new Cartitems(),
    FoodCompanies: new FoodCompanies(),
    Events: new Events(),
    FoodEventPlot: new FoodEventPlot(),
    Plots: new Plots(),
    Sponsorpartners: new SponsorPartners(),
    Categories: new Categories(),
    Discounts: new Discounts(),
    Bookmarks: new Bookmarks(),
    Ratings: new Ratings(),
    Notifications: new Notifications(),
    Faqs: new Faqs(), 
    Promotions: new Promotions(), 
    Memberships: new Memberships(), 
    PopularSearches: new PopularSearches(),
    Discounts: new Discounts(),
}

export default db