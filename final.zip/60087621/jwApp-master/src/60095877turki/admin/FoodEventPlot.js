import React, { useEffect, useState } from 'react'
import db from '../../db'
import Button from 'react-bootstrap/Button';

function FoodEventPlot({ fep, edit, remove }) {

    // const { id: stringId } = useParams();
    // const id = 1 * stringId

    // const [product, setProduct] = useState(null)
    // useEffect(() => (async () => setProduct(await db.Products.findOne(id)))(), [id])
    // const [validRemove, setValidRemove] = useState(false)
    // useEffect(() => (async () => setValidRemove(
    //     (await db.Cartitems.findByCartid(cartitem.id)).length === 0
    // ))(), [cartitem.id])


    // useEffect(() => {
    //     (async()=>{
    //         let items = await db.Cartitems.findByCartid(cart.id)
    //         console.log("AAAAAAAAA",items)

    //         await Promise.all(items.map(async e => {
    //             console.log("the e",e.id)
    //             await db.Cartitems.removeNoSet(e.id)
    //         }    
    //         ))
    //         db.Carts.removeNoSet(cart.id)
    //     })()
    // },[])


    const [event, setEventid] = useState(0)
    const [foodCompany, setFoodCompanyid] = useState(0)
    const [plot, setPlotid] = useState(0)

    useEffect(() => (async () => setEventid(await db.Events.findOne(fep.eventid)))(), [fep.eventid])
    useEffect(() => (async () => setFoodCompanyid(await db.FoodCompanies.findOne(fep.foodCompanyid)))(), [fep.foodCompanyid])
    useEffect(() => (async () => setPlotid(await db.Plots.findOne(fep.plotid)))(), [fep.plotid])

    return (
        <tr>
            <td>{fep.eventid}</td>
            <td>{fep.foodCompanyid}</td>
            <td>{fep.plotid}</td>

            <td>
                <Button size="sm" variant="light" onClick={() => remove(fep.id)} >X</Button>
                <Button size="sm" variant="light" onClick={() => edit(fep.id)}>edit</Button>
            </td>
        </tr>
    )
}

export default FoodEventPlot;

