import React, { useEffect, useState, useContext } from 'react'
import db from '../../db'
import Button from 'react-bootstrap/Button';
import Bookmarks from '../../60087621Mahmoud/Bookmarks'
import UserContext from '../../UserContext'

function Event({ event, edit, remove }) {

  const [validRemove, setValidRemove] = useState(false)
  useEffect(() => (async () => setValidRemove(
    event.id &&
    (await db.Events.findEventById(event.id)).length > 0
  ))(), [event])


  const [bookmark, setBookmarks] = useState([])
  const [id, setId] = useState(0)
  const [eventid, setEventid] = useState(0)
  const [userid, setUserid] = useState("")
  const [type, setType] = useState("")

  const {user} = useContext(UserContext)
  useEffect(() => (async () => setBookmarks(await db.Bookmarks.findAll()))(), [])


    const create = async () => {
    await db.Bookmarks.create(setBookmarks, { eventid:event.id , userid:user.id, type:event.type })
    setId(0)
    setEventid(0)
    setUserid("")
    setType("")
  }
  const [validCreate, setValidCreate] = useState(false)
  useEffect(() => (async () => setValidCreate(
    eventid > 0 &&
    userid !== "" &&
    type !== "" &&
    (await db.Users.findOne(userid)) !== undefined &&
    (await db.Events.findOne(eventid)) !== undefined &&
    (await db.Bookmarks.findOne(id)) !== undefined
  ))(), [userid, eventid, type])

  return (
    <tr>
      <td>{event.name}</td>
      <td>{event.type}</td>
      <td>{event.startdate.toDateString()}</td>
      <td>{event.enddate.toDateString()}</td>
      <td>{event.status}</td>
      <td>{event.sponsorpartnerid}</td>


      <td>
      {user.role === "Admin" ?<Button size="sm" variant="light" onClick={() => remove(event.id)} disabled={!validRemove}>X</Button>:null}
        {user.role === "Admin" ?<Button size="sm" variant="light" onClick={() => edit(event.id)}>Edit</Button>:null}

        {user.role === "Admin" ?<Button size="sm" variant="light" onClick={() => create(event.id)} disabled={validCreate}>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bookmark-plus-fill" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M2 15.5V2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.74.439L8 13.069l-5.26 2.87A.5.5 0 0 1 2 15.5zm6.5-11a.5.5 0 0 0-1 0V6H6a.5.5 0 0 0 0 1h1.5v1.5a.5.5 0 0 0 1 0V7H10a.5.5 0 0 0 0-1H8.5V4.5z" />
          </svg>
        </Button>:null}
      </td>
    </tr>


  )
}

export default Event;