import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import FoodEventPlot from './FoodEventPlot'

export default function FoodEvenPlots() {

  const [foodeventplots, setFoodeventplots] = useState([])
  const [id, setId] = useState(0)
  const [eventid, setEventid] = useState(0)
  const [foodCompanyid, setFoodCompanyid] = useState(0)
  const [plotid, setPlotid] = useState(0)


  useEffect(() => (async () => setFoodeventplots(await db.FoodEventPlot.findAll()))(), [])



  const create = async () => {
    await db.FoodEventPlot.create(setFoodeventplots, {eventid, foodCompanyid, plotid})
    setId(0)
    setEventid(0)
    setFoodCompanyid(0)
    setPlotid(0)
    
  }

  const remove = async id => await db.FoodEventPlot.remove(setFoodeventplots, id)

  const edit = async id => {
    const foodeventplot = await db.FoodEventPlot.findOne(id)
    setId(foodeventplot.id)
    setEventid(foodeventplot.eventid)
    setFoodCompanyid(foodeventplot.foodCompanyid)
    setPlotid(foodeventplot.plotid)
  }

  // update is step 2
  const update = async () => {
    await db.FoodEventPlot.update(setFoodeventplots, {eventid,foodCompanyid,plotid})
    setId(0)
    setEventid(0)
    setFoodCompanyid(0)
    setPlotid(0)
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(()=> async () => setValidCreate(
    eventid>0&&
    await db.Event.findOne(eventid) !== undefined&&
    await db.FoodCompanies.findOne(foodCompanyid) !== undefined&&
    await db.Plots.findOne(plotid) !== undefined
  ), [eventid, foodCompanyid, plotid])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    eventid>0&&
    await db.FoodEventPlot.findOne(id) !== undefined&&
    await db.Event.findOne(eventid) !== undefined&&
    await db.FoodCompanies.findOne(foodCompanyid) !== undefined&&
    await db.Plots.findOne(plotid) !== undefined
  ))(), [id, eventid, foodCompanyid, plotid])


  return (
    <div>
      <h1>Food Event Plot </h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Event id</th>
            <th>Food company</th>
            <th>Plot id</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setEventid(event.target.value)} placeholder="Event id" value={eventid} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setFoodCompanyid(event.target.value)} placeholder="Food Company id" value={foodCompanyid} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setPlotid(event.target.value)} placeholder="Plot id" value={plotid} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>
          {
            foodeventplots.map(fep =>
              <FoodEventPlot key={fep.id} fep={fep} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}