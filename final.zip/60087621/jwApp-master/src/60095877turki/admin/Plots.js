import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Plot from './Plot'

export default function Plots() {

  const [plots, setPlots] = useState([])
  const [id, setId] = useState(0)
  const [layout, setLayout] = useState("")
  const [squarefoot, setSquarefoot] = useState(0)
  const [price,setPrice] = useState(0)
  const [availability, setAvailability] = useState("")



  useEffect(() => (async () => setPlots(await db.Plots.findAll()))(), [])

  const create = async () => {
    await db.Plots.create(setPlots, {layout, squarefoot, price, availability})
    setId(0)
    setSquarefoot(0)
    setLayout("")
    setAvailability("")
    setPrice(0)

  }

  const remove = async id => await db.Plots.remove(setPlots, id)

  const edit = async id => {
    const plot = await db.Plots.findOne(id)
    setId(plot.id)
    setSquarefoot(plot.squarefoot)
    setLayout(plot.layout)
    setAvailability(plot.availability)
    setPrice(plot.price)
  }

  // update is step 2
  const update = async () => {
    await db.Plots.update(setPlots, {id, layout, squarefoot, price, availability})
    setId(0)
    setSquarefoot(0)
    setLayout("")
    setAvailability("")
    setPrice(0)
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(()=> async () => setValidCreate(
    squarefoot >0 &&
    layout !=="" &&
    availability!==""&&
    price > 0
  ), [layout,squarefoot, price, availability])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    id>0&&
    squarefoot >0 &&
    layout !=="" &&
    availability!==""&&
    price > 0&&
    await db.Plots.findOne(id) !== undefined
  ))(), [id,layout,squarefoot, price, availability])


  return (
    <div>
      <h1>Plots</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Square Foot</th>
            <th>Layout</th>
            <th>Availability</th>
            <th>Price</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setSquarefoot(1 * event.target.value)} placeholder="Square Foot" value={squarefoot} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setLayout(event.target.value)} placeholder="Layout" value={layout} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setAvailability(event.target.value)} placeholder="Availability" value={availability} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setPrice(1 * event.target.value)} placeholder="Price" value={price} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>
          {
            plots.map(plot =>
              <Plot key={plot.id} plot={plot} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}