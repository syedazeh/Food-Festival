import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Event from './Event'

export default function Events({user}) {

  const [events, setEvents] = useState([])
  const [id, setId] = useState(0)
  const [sponsorpartnerid, setSponsorpartnerid] = useState(0)
  const [name, setName] = useState("")
  const [type, setType] = useState("")
  const [startdate, setStartdate] = useState(new Date())
  const [enddate, setEnddate] = useState(new Date())
  const [status, setStatus] = useState("")



  useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])

  const create = async () => {
    await db.Events.create(setEvents, {sponsorpartnerid, name, type, startdate, enddate, status })
    setId(0)
    setSponsorpartnerid(0)
    setName("")
    setType("")
    setStartdate(new Date())
    setEnddate(new Date())
    setStatus(0)

  }

  const remove = async id => await db.Events.remove(setEvents, id)

  const edit = async id => {
    const event = await db.Events.findOne(id)
    setId(event.id)
    setSponsorpartnerid(event.sponsorpartnerid)
    setName(event.name)
    setType(event.type)
    setStartdate(event.startdate)
    setEnddate(event.enddate)
    setStatus(event.status)
  }

  // update is step 2
  const update = async () => {
    await db.Events.update(setEvents, {id,sponsorpartnerid, name, type, startdate, enddate, status })
    setId(0)
    setSponsorpartnerid(0)
    setName("")
    setType("")
    setStartdate(new Date())
    setEnddate(new Date())
    setStatus(0)
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(()=>(async () => setValidCreate(
    name !== "" &&
    type !== "" &&
    startdate >= new Date()&&
    enddate >= startdate&&
    status !== "" && 
    (await db.Sponsorpartner.findOne(sponsorpartnerid)) !== undefined

  ))(), [sponsorpartnerid,name, type, startdate, enddate, status])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    name !== "" &&
    id>0&&
    type !== "" &&
    startdate >= new Date()&&
    enddate >= startdate&&
    status !== ""&&
    await db.Sponsorpartner.findOne(sponsorpartnerid) !== undefined&&
    await db.Events.findOne(id) !== undefined
  ))(), [id,sponsorpartnerid,name, type, startdate, enddate, status])
console.log(name)
console.log(type)
console.log(startdate)
console.log(enddate)
console.log(status)
console.log(sponsorpartnerid)


  startdate&&
  console.log(startdate.toLocaleDateString('en-CA'))
  return (
    <div>
      <h1>Events</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Start date</th>
            <th>End date</th>
            <th>Status</th>
            <th>Sponsor partner</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
        {user.role === "Admin" ?
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setName(event.target.value)} placeholder="Name" value={name} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setType(event.target.value)} placeholder="Type" value={type} />
            </td>
            <td>
              <Form.Control size="sm" type="date" onChange={event => setStartdate(new Date(event.target.value))} placeholder="Start Date" value={startdate.toLocaleDateString('en-CA')} />
            </td>
            <td>
              <Form.Control size="sm" type="date" onChange={event => setEnddate(new Date(event.target.value))} placeholder="End Date" value={enddate.toLocaleDateString('en-CA')} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setStatus(event.target.value)} placeholder="Status" value={status} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setSponsorpartnerid(1 * event.target.value)} placeholder="Status" value={sponsorpartnerid} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>:null}
          {
            events.map(event =>
              <Event key={event.id} event={event} user={user} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}