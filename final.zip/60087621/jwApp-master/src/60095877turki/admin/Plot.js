import React, { useEffect, useState } from 'react'
import db from '../../db'
import Button from 'react-bootstrap/Button';

function Plot({ plot,edit, remove }) {

    // const { id: stringId } = useParams();
    // const id = 1 * stringId

    // const [product, setProduct] = useState(null)
    // useEffect(() => (async () => setProduct(await db.Products.findOne(id)))(), [id])
    // const [validRemove, setValidRemove] = useState(false)
    // useEffect(() => (async () => setValidRemove(
    //     (await db.Cartitems.findByCartid(cartitem.id)).length === 0
    // ))(), [cartitem.id])


    // useEffect(() => {
    //     (async()=>{
    //         let items = await db.Cartitems.findByCartid(cart.id)
    //         console.log("AAAAAAAAA",items)

    //         await Promise.all(items.map(async e => {
    //             console.log("the e",e.id)
    //             await db.Cartitems.removeNoSet(e.id)
    //         }    
    //         ))
    //         db.Carts.removeNoSet(cart.id)
    //     })()
    // },[])
        console.log(plot)
    return (
        <tr>
            <td>{plot.squarefoot}</td>
            <td>{plot.layout}</td>
            <td>{plot.availability}</td>
            <td>{plot.price}</td>

            <td>
                <Button size="sm" variant="light" onClick={() => remove(plot.id)} >X</Button>
                <Button size="sm" variant="light" onClick={() => edit(plot.id)} >edit</Button>

            </td>
        </tr>
    )
}

export default Plot;

