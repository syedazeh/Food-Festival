import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import FoodCompany from './FoodCompany'

export default function FoodCompanies({user}) {

  const [foodcompanies, setFoodcompanies] = useState([])
  const [id, setId] = useState(0)
  const [name, setName] = useState("")
  const [address, setAddress] = useState("")
  const [website, setWebsite] = useState("")
  const [position, setPosition] = useState("")
  const [phone, setPhone] = useState(0)
  const [email, setEmail] = useState("")




  useEffect(() => (async () => setFoodcompanies(await db.FoodCompanies.findAll()))(), [])

  const create = async () => {
    await db.FoodCompanies.create(setFoodcompanies, { name, address, website, position, phone, email })
    setId(0)
    setName("")
    setAddress("")
    setWebsite("")
    setPosition("")
    setPhone(0)
    setEmail("")

  }

  const remove = async id => await db.FoodCompanies.remove(setFoodcompanies, id)

  const edit = async id => {
    const foodcompany = await db.FoodCompanies.findOne(id)
    setId(foodcompany.id)
    setName(foodcompany.name)
    setAddress(foodcompany.address)
    setWebsite(foodcompany.website)
    setPosition(foodcompany.position)
    setPhone(foodcompany.phone)
    setEmail(foodcompany.email)
  }

  // update is step 2
  const update = async () => {
    await db.FoodCompanies.update(setFoodcompanies, { id, name, address, website, position, phone, email })
    setId(0)
    setName("")
    setAddress("")
    setWebsite("")
    setPosition("")
    setPhone(0)
    setEmail("")
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(() => async () => setValidCreate(
    address !== "" &&
    name !== "" &&
    position !== "" &&
    website !== "" &&
    email !== "" &&
    phone >= 1 &&
    phone <= 99999999
  ), [name, address, website, position, phone, email])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(

    address !== "" &&
    name !== "" &&
    position !== "" &&
    website !== "" &&
    email !== "" &&
    phone >= 1 &&
    phone <= 99999999999 &&
    await db.FoodCompanies.findOne(id) !== undefined
  ))(), [id, name, address, website, position, phone, email])


  return (
    <div>
      <h1>Food Companies</h1>
      <Form>
        <Form.Row>
          <Form.Group controlId="formGridName">
            <Form.Label>Name</Form.Label>
            <Form.Control size="sm" type="text" onChange={event => setName(event.target.value)} placeholder="Name" value={name} />
          </Form.Group>
          <Form.Group controlId="formGridPosition">
            <Form.Label>Position</Form.Label>
            <Form.Control size="sm" type="text" onChange={event => setPosition(event.target.value)} placeholder="Position" value={position} />
          </Form.Group>
          <Form.Group controlId="formGridWebsite">
            <Form.Label>Website</Form.Label>
            <Form.Control size="sm" type="text" onChange={event => setWebsite(event.target.value)} placeholder="Website" value={website} />
          </Form.Group>
        </Form.Row>
        <Form.Row>
          <Form.Group controlId="formGridEmail">
            <Form.Label>Email</Form.Label>
            <Form.Control size="sm" type="text" onChange={event => setEmail(event.target.value)} placeholder="E-mail" value={email} />
          </Form.Group>
          <Form.Group controlId="formGridAddress">
            <Form.Label>Address</Form.Label>
            <Form.Control size="sm" type="text" onChange={event => setAddress(event.target.value)} placeholder="Address" value={address} />
          </Form.Group>
          <Form.Group controlId="formGridPhone">
            <Form.Label>Phone</Form.Label>
            <Form.Control size="sm" type="number" onChange={event => setPhone(event.target.value)} placeholder="Phone" value={phone} />
          </Form.Group>
        </Form.Row>
        <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
        {
        user.role === "Admin"?
        <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>:null
}
      </Form>
      <br />
      <br />
      <br />
      {
        user.role === "Admin" || user.role === "Support" ?
          <Table striped bordered hover variant="dark" size="sm">
            <thead>
              <tr>
                <th>Address</th>
                <th>Company Name</th>
                <th>Position</th>
                <th>Website</th>
                <th>E-mail</th>
                <th>Phone</th>
              </tr>
            </thead>
            <tbody>
              {
                foodcompanies.map(foodcompany =>
                  <FoodCompany key={foodcompany.id} user={user} foodcompany={foodcompany} edit={edit} remove={remove} />
                )
              }
            </tbody>
          </Table> : null
      }




    </div >
  );
}




