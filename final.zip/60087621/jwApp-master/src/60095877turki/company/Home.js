import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Product from './Product'
import CardGroup from 'react-bootstrap/CardGroup'
import Alert from 'react-bootstrap/Alert'
import Card from 'react-bootstrap/Card'
import Button from 'react-bootstrap/Button'
import { Link } from "react-router-dom";
import Carousel from 'react-bootstrap/Carousel'
import Event from '../../60095877turki/public/Event'

export default function Home() {

  const [products, setProducts] = useState([])

  useEffect(() => (async () => setProducts(await db.Products.findAll()))(), [])

  const [events, setEvents] = useState([])

  useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])

  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };
  


  return (
    <>
      {/* < div class="ModuleVideoEmbedded-module--aspectWrapper---thoP" >
      <video autoplay="" playsinline="" loop="" muted="" controls="" width="100%">
        <source src="//videos.ctfassets.net/2h1qowfuxkq7/6byY4lJKmVRhajkUYWLedF/9d995ddfd941bfd3ef72205378f792c0/GENERIC_ENG_NEW.mp4" type="video/mp4">
        </source>
      </video>
    </div >
    <div>
<p></p>
</div> */}

      <br></br>
      <br></br>
      <Alert variant="success">
        <p style={{ fontSize: '2em' }}>
          Want to buy a plot for our food festival?
          <Alert.Link as={Link} to={`/register`}> Click here!</Alert.Link>
        </p>
      </Alert>


      <h1>Tickets</h1>
      <CardGroup>
        {
          products.map(product => <Product key={product.id} product={product} />)
        }
      </CardGroup>


      <Carousel activeIndex={index} onSelect={handleSelect}>
        {
          events.map(event => <Event key={event.id} event={event} />)
        }
      </Carousel>
    </>
  )
}