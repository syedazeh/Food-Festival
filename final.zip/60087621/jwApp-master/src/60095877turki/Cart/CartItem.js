import React from 'react'
// import db from '../../db'
import Button from 'react-bootstrap/Button';

function CartItem({ cartitem, remove }) {

    // const { id: stringId } = useParams();
    // const id = 1 * stringId

    // const [product, setProduct] = useState(null)
    // useEffect(() => (async () => setProduct(await db.Products.findOne(id)))(), [id])
    // const [validRemove, setValidRemove] = useState(false)
    // useEffect(() => (async () => setValidRemove(
    //     (await db.Cartitems.findByCartid(cartitem.id)).length === 0
    // ))(), [cartitem.id])


    // useEffect(() => {
    //     (async()=>{
    //         let items = await db.Cartitems.findByCartid(cart.id)
    //         console.log("AAAAAAAAA",items)

    //         await Promise.all(items.map(async e => {
    //             console.log("the e",e.id)
    //             await db.Cartitems.removeNoSet(e.id)
    //         }    
    //         ))
    //         db.Carts.removeNoSet(cart.id)
    //     })()
    // },[])
        console.log(cartitem)
    return (
        <tr>
            <td>{cartitem.quantity}</td>
            <td>{cartitem.productid}</td>



            <td>
                <Button size="sm" variant="light" onClick={() => remove(cartitem.id)} >X</Button>
                
            </td>
        </tr>
    )
}

export default CartItem;

