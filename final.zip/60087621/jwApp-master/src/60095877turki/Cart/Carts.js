import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Cart from './Cart';

export default function Mycart({user}) {

  const [carts, setCarts] = useState([])
  const [id, setId] = useState(0)
  const [status, setStatus] = useState('')
  const [userid, setUserid] = useState(0)
  const [totalprice, setTotalPrice] = useState(0)
 


  useEffect(() => (async () => setCarts(await db.Carts.findAll()))(), [])

  const create = async () => {
    await db.Carts.create(setCarts, {id, status, userid, totalprice})
    setId(0)
    setStatus('')
    setUserid(0)
    setTotalPrice(0)
  }

  const remove = async id => await db.Carts.remove(setCarts, id)

  const edit = async id => {
    const cart = await db.Carts.findOne(id)
    setId(cart.id)
    setStatus(cart.status)
    setUserid(cart.userid)
    setTotalPrice(cart.totalprice)
  }

  // update is step 2
  const update = async () => {
    await db.Carts.create(setCarts,  {id, status, userid, totalprice})
    setId(0)
    setStatus('')
    setUserid(0)
    setTotalPrice(0)
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(()=>(async () => setValidCreate(
    status > 0&&
    totalprice!== null&&
    (await db.Users.findOne(userid)) === undefined

  ))(), [id, status, userid, totalprice])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    status > 0 &&
    totalprice !== null &&
    await db.Users.findOne(userid) !== undefined&&
    await db.CartItems.findOne(id) !== undefined&&
    await db.Carts.findOne(id) !== undefined
  ))(), [id, status, userid, totalprice])

  return (
    <div>
      <h1>Carts</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Status</th>
            <th>Total Price</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
        {user.role === "Admin" ?
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setStatus(event.target.value)} placeholder="Status" value={status} />
            </td>
            <td>
              <Form.Control size="sm" type="number" onChange={event => setTotalPrice(event.target.value)} placeholder="Price" value={totalprice} />
            </td>
            
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
                
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>:null}
          {
            carts.map(cart =>
              <Cart key={cart.id} cart={cart} edit={edit} user={user} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}