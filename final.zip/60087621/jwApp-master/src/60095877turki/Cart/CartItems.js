import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
// import Form from 'react-bootstrap/Form';
import CartItem from './CartItem'
import {
  useParams
} from "react-router-dom";

export default function CartItems() {

  const { id: stringId } = useParams();
  const cartid1 = 1 * stringId
  const [cartitems1, setCartitems1] = useState([])
  const [cart, setCart] = useState([])
  useEffect(() => (async () => setCartitems1(await db.Cartitems.findByCartid(cartid1)))(), [cartid1])
  useEffect(() => (async () => setCart(await db.Carts.findOne(cartid1)))(), [cartid1])



  console.log(cartid1)

  const [cartitems, setCartitems] = useState([])
  // const [id, setId] = useState(0)
  // const [quantity, setQuantity] = useState(0)
  // const [cartid, setCartid] = useState(0)
  // const [productid, setProductid] = useState(0)
 


  useEffect(() => (async () => setCartitems(await db.Cartitems.findAll()))(), [])

  // const create = async () => {
  //   await db.Cartitems.create(setCartitems, {id, quantity, cartid, productid})
  //   setId(0)
  //   setQuantity(1)
  //   setCartid(0)
  //   setProductid(0)
  // }

  const remove = async id => await db.Cartitems.remove(setCartitems, id)

  // const edit = async id => {
  //   const cartitem = await db.Cartitems.findOne(id)
  //   setId(cartitem.id)
  //   setQuantity(cartitem.quantity)
  //   setCartid(cartitem.cartid)
  //   setProductid(cartitem.productid)
  // }

  // update is step 2
  // const update = async () => {
  //   await db.Cartitems.create(setCartitems, {id, quantity, cartid, productid})
  //   setId(0)
  //   setQuantity()
  //   setCartid(0)
  //   setProductid(0)
  // }

  // const [validCreate, setValidCreate] = useState(false)
  // useEffect(()=>(async () => setValidCreate(
  //   quantity > 0&&
  //   (await db.Carts.findOne(cartid) === undefined&&
  //   await db.Products.findOne(productid)) === undefined

  // ))(), [id, quantity, cartid, productid])

  // const [validUpdate, setValidUpdate] = useState(false)
  // useEffect(() => (async () => setValidUpdate(
  //   quantity > 0 &&
  //   productid !== null &&
  //   await db.Users.findOne(cartid) !== undefined&&
  //   await db.CartItems.findOne(id) !== undefined&&
  //   await db.Carts.findOne(id) !== undefined
  // ))(), [id, quantity, cartid, productid])

  console.log(cart)
  const checkOut = async s =>{
    console.log(s)
    await db.Carts.update(setCart, {id:cartid1, status:s, userid:cart.userid, totalprice:cart.totalprice})
  }

  console.log(cart)
  return (
    <div>
      <h1>Cart Items</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Quantity</th>
            <th>Product id</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
          {/* <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setQuantity(event.target.value)} placeholder="Quantity" value={quantity} />
            </td>
            <td>
              <Form.Control size="sm" type="number" onChange={event => setProductid(event.target.value)} placeholder="Product Id" value={productid} />
            </td>
            
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr> */}
          {
            cartitems1.map(cartitem =>
              <CartItem key={cartitem.id} cartitem={cartitem} remove={remove} />
            )
          }
        </tbody>
      </Table>
      <Button size="sm" variant="light" onClick={() => checkOut("paid")} >checkOut</Button>
    </div >
  );
}