import React, { useEffect, useState } from 'react'
import db from '../../db'
import Button from 'react-bootstrap/Button';
import {

    Link
} from "react-router-dom"

function Mycart({ cart, edit, remove }) {


    // const { id: stringId } = useParams();
    // const cartid1 = 1 * stringId

    const [validRemove, setValidRemove] = useState(false)
    useEffect(() => (async () => setValidRemove(
        (await db.Cartitems.findByCartid(cart.id)).length === 0
    ))(), [cart.id])

    const [cartitem, setCartitem] = useState(false)
    useEffect(() => (async () => setCartitem(
        (await db.Cartitems.findByCartid(cart.id)).length === 0
    ))(), [cart.id])


    // useEffect(() => {
    //     (async()=>{
    //         let items = await db.Cartitems.findByCartid(cart.id)
    //         console.log("AAAAAAAAA",items)

    //         await Promise.all(items.map(async e => {
    //             console.log("the e",e.id)
    //             await db.Cartitems.removeNoSet(e.id)
    //         }    
    //         ))
    //         db.Carts.removeNoSet(cart.id)
    //     })()
    // },[])
        console.log(cart.id)
        console.log(cartitem.id)
    return (
        <tr>
            <td>{cart.status}</td>
            <td>{cart.totalprice}</td>



            <td>
                <Button size="sm" variant="light" onClick={() => remove(cart.id)} disabled={!validRemove}>X</Button>
                <Button size="sm" variant="link" as={Link} to={`/cartitems/${cart.id}`}>Details</Button>
            </td>
        </tr>
    )
}

export default Mycart;