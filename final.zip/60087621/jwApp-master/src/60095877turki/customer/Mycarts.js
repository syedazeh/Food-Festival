import React, { useEffect, useState, useContext } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Mycart from './Mycart'
import {
  useParams
} from "react-router-dom";

import UserContext from '../../UserContext'


export default function Mycarts() {
  // const { id: stringId } = useParams();
  // const userid1 = stringId
  
  const {user} = useContext(UserContext)


  const params = useParams()
  const [carts, setCarts] = useState([])
 
console.log(user);

  useEffect(() => (async () => setCarts(await db.Carts.findCartByUseridAndStatus(user.id,"paid")))(), [])



  return (
    <div>
      <h1>Carts</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Status</th>
            <th>Total Price</th>
            <th></th>

          </tr>
        </thead>
        <tbody>

          {
            carts.map(cart =>
              <Mycart key={cart.id} cart={cart} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}