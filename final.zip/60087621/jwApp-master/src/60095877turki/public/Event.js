import React, { useEffect, useState } from 'react'
import db from '../../db'
import Button from 'react-bootstrap/Button';
import Carousel from 'react-bootstrap/Carousel'

function Event({ event }) {

  const [validRemove, setValidRemove] = useState(false)
  useEffect(() => (async () => setValidRemove(
    event.id &&
    (await db.Events.findEventById(event.id)).length > 0
  ))(), [event])

  return (
    // <tr>
    //   <td>{event.name}</td>
    //   <td>{event.type}</td>
    //   <td>{event.startdate.toDateString()}</td>
    //   <td>{event.enddate.toDateString()}</td>
    //   <td>{event.status}</td>
    //   <td>{event.sponsorpartnerid}</td>

    // </tr>

    <Carousel.Item>
      <img
        className="d-block w-100"
        src="holder.js/800x400?text=First slide&bg=373940"
        alt="First slide"
      />
      <Carousel.Caption>
        <h3>{event.name}</h3>
        <p>{event.type}</p>
      </Carousel.Caption>
    </Carousel.Item>
  )
}

export default Event;