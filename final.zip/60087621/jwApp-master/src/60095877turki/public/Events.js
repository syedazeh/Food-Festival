import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Event from './Event'
import Carousel from 'react-bootstrap/Carousel'


export default function Events() {

  const [events, setEvents] = useState([])
  const [id, setId] = useState(0)
  const [sponsorpartnerid, setSponsorpartnerid] = useState(0)
  const [name, setName] = useState("")
  const [type, setType] = useState("")
  const [startdate, setStartdate] = useState(new Date())
  const [enddate, setEnddate] = useState(new Date())
  const [status, setStatus] = useState("")

  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  }

  useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])

  const create = async () => {
    await db.Events.create(setEvents, {sponsorpartnerid, name, type, startdate, enddate, status })
    setId(0)
    setSponsorpartnerid(0)
    setName("")
    setType("")
    setStartdate(new Date())
    setEnddate(new Date())
    setStatus(0)

  }

  const remove = async id => await db.Events.remove(setEvents, id)

  const edit = async id => {
    const event = await db.Events.findOne(id)
    setId(event.id)
    setSponsorpartnerid(event.sponsorpartnerid)
    setName(event.name)
    setType(event.type)
    setStartdate(event.startdate)
    setEnddate(event.enddate)
    setStatus(event.status)
  }

  // update is step 2
  const update = async () => {
    await db.Events.update(setEvents, {id,sponsorpartnerid, name, type, startdate, enddate, status })
    setId(0)
    setSponsorpartnerid(0)
    setName("")
    setType("")
    setStartdate(new Date())
    setEnddate(new Date())
    setStatus(0)
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(()=>(async () => setValidCreate(
    name !== "" &&
    type !== "" &&
    startdate >= new Date()&&
    enddate >= startdate&&
    status !== "" && 
    (await db.Sponsorpartner.findOne(sponsorpartnerid)) !== undefined

  ))(), [sponsorpartnerid,name, type, startdate, enddate, status])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    name !== "" &&
    id>0&&
    type !== "" &&
    startdate >= new Date()&&
    enddate >= startdate&&
    status !== ""&&
    await db.Sponsorpartner.findOne(sponsorpartnerid) !== undefined&&
    await db.Events.findOne(id) !== undefined
  ))(), [id,sponsorpartnerid,name, type, startdate, enddate, status])
console.log(name)
console.log(type)
console.log(startdate)
console.log(enddate)
console.log(status)
console.log(sponsorpartnerid)


  startdate&&
  console.log(startdate.toLocaleDateString('en-CA'))
  return (
    <div>
      <h1>Events</h1>
     
      <Carousel activeIndex={index} onSelect={handleSelect}>
        {
          events.map(event => <Event key={event.id} event={event} />)
        }
      </Carousel>
    </div >
  );
}