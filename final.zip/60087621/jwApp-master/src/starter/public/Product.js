import React from 'react'
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";
import Card from 'react-bootstrap/Card'


export default function Product({ product }) {

  return (
    <>
      <Card style={{ width: '18rem', height: '22rem', float: 'left', margin: '10px 30px 30px 10px' }}>
        <Card.Body>
          <Card.Title>{product.name}</Card.Title>
          <Card.Subtitle className="mb-2 text-muted">{product.price} QR</Card.Subtitle>
          <Card.Text>
            {
              product.name === 'VIP Ticket' ?
                <>
                  <p><b>Each Ticket Inlcudes</b></p>
                  <p>
                    Festival Entry <br></br>
                    Access To All Features <br></br>
                    Exclusive VIP Lounge Access
                  </p>
                </>
                : (product.name === 'Gold Ticket'
                  ?
                  <>
                    <p><b>Each Ticket Inlcudes</b></p>
                    <p>
                      Festival Entry <br></br>
                      Access To All Features <br></br>
                      Exclusive VIP Lounge Access<br></br>
                      Be able to cook alongside chefs in the Live Cooking Theatre
                    </p>
                  </>
                  :
                  <>
                    <p><b>Each Ticket Inlcudes</b></p>
                    <p>Standard Festival Entry</p>
                  </>
                )
            }
          </Card.Text>
          <Button size="sm" variant="link" variant="dark" as={Link} to={`/productdetail/${product.id}`}>Detail</Button>
          <br></br>
          <br></br>
          <Button size="sm" variant="link" variant="dark" as={Link} to={`/buyproduct/${product.id}`}>Buy</Button>
        </Card.Body>
      </Card>
    </>
  )
}