import React, { useEffect, useState, useContext } from 'react'
import db from '../../db'
import {
    useParams
} from "react-router-dom";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
// import Mycartitems from '../../60095877turki/customer/MycartItems'
import { Link } from "react-router-dom";

import UserContext from '../../UserContext'



export default function BuyProduct() {

    const {user} = useContext(UserContext)
    const [cart, setCart] = useState([])
    useEffect(() => (async () => setCart(await db.Carts.findCartByUseridAndStatus(user.id,"Unpaid")))(), [])

    

    console.log(cart);

    const { id: stringId } = useParams();
    const id = 1 * stringId

    const [cartitem, setCartitem] = useState([])
    useEffect(() => (async () => cart.length > 0 && setCartitem(await db.Cartitems.findByCartidAndProductid(cart[0].id,id)))(), [])

    console.log("lasdkfladsjflakds",cartitem)

    const [product, setProduct] = useState(null)
    useEffect(() => (async () => setProduct(await db.Products.findOne(id)))(), [id])

    const [num, setNum] = useState(1)

    const [validAdd, setValidAdd] = useState(false)
    useEffect(() => setValidAdd(
        num <= 4), [num])

    const [validNum, setValidNum] = useState(false)
    useEffect(() => setValidNum(
        num >= 1 ), [num])


        console.log(cart.length>0 && cart[0].id)
        console.log(cartitem)
        console.log(id)
        console.log(num)
        const buyFunc = async () =>{
        let total = 0
        let x = product.price
        console.log(num)
        for(let i = 0; i < num; i++) {  
            total= total + x
        };
        // console.log(total);
        
            console.log("here for up")
            await db.Carts.update(setCart,  {status:cart[0].status, userid:user.id, totalprice:total})
            
            if(cartitem.length>0){
                await db.Cartitems.update(()=>{}, {id: cartitem[0].id,quantity:num,cartid:cart.length>0 && cart[0].id,productid:id})
            }

            if(cart[0].length <0 || cart[0].length){
                await db.Carts.create(() => {},{status:"paid",userid:user.id,totalprice:0})
            }
            
        
        // <Mycartitems quant={num} totalp={total}/>
    }
    return (

        <>
            <h1>Product</h1>
            <Button size="sm" variant="light" onClick={() => setNum(num + 1)} disabled={!validAdd}>+</Button>
            <Form.Control size="sm" type="number" onChange={event => setNum(1 * event.target.value)} placeholder="Product Id" value={num} />
            <Button size="sm" variant="light" onClick={() => setNum(num - 1)} disabled={!validNum}>-</Button>

            <br/>
            <br/>
            <Button size="sm" as={Link} to={`/mycartitems/${cart.length> 0 && cart[0].id}`} onClick={() => buyFunc()}>Buy</Button>
        </> 
    )
}