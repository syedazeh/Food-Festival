import React, { useEffect, useState } from 'react'
import db from '../../../../db'
import {
  useParams
} from "react-router-dom";

export default function ProductDetail() {

  const { id: stringId } = useParams();
  const id = 1 * stringId

  const [product, setProduct] = useState([])
  useEffect(() => (async () => setProduct(await db.Products.findOne(id)))(), [id])
  console.log(product);

  const [event, setEvents] = useState([])
  useEffect(() => (async () => await db.Events.findOne())(), [])
  const [discount, setDiscount] = useState([])
  useEffect(() => (async () => await db.Discounts.findOne())(), [])

  const [category, setCategory] = useState([])
  useEffect(() => (async () => await db.Categories.findOne())(), [])

  console.log(discount, event, category);

  return (
    product
    &&
    <>
      <h1>Product</h1>
      <dl className="row">
        <dt className="col-sm-3">Name</dt>
        <dd className="col-sm-9">{product.name}</dd>
        <dt className="col-sm-3">Price</dt>
        <dd className="col-sm-9">{product.price}</dd>
      </dl>
    </>
  )
}