import React, { useEffect, useState } from 'react'
import db from '../../../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Product from './Product'



export default function Products({ user }) {

  const [products, setProducts] = useState([])
  const [id, setId] = useState(0)
  const [name, setName] = useState("")
  const [price, setPrice] = useState(0)
  const [categoryid, setCategoryid] = useState(0)
  const [discountid, setDiscountid] = useState(0)
  const [eventid, setEventid] = useState(0)
  useEffect(() => (async () => setProducts(await db.Products.findAll()))(), [])


  const [events, setEvents] = useState([])
  const [category, setCategory] = useState([])
  const [discount, setDiscount] = useState([])
  useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])
  useEffect(() => (async () => setCategory(await db.Categories.findAll()))(), [])
  useEffect(() => (async () => setDiscount(await db.Discounts.findAll()))(), [])


  const create = async () => {
    await db.Products.create(setProducts, { name, price, categoryid, discountid, eventid })
    setId(0)
    setName("")
    setPrice(0)
    setCategoryid(0)
    setDiscountid(0)
    setEventid(0)
  }

  const remove = async id => await db.Products.remove(setProducts, id)

  const edit = async id => {
    const product = await db.Products.findOne(id)
    setId(product.id)
    setName(product.name)
    setPrice(product.price)
    setCategoryid(product.categoryid)
    setDiscountid(product.discountid)
    setEventid(product.eventid)
  }

  // update is step 2
  const update = async () => {
    await db.Products.update(setProducts, { id, name, price, categoryid, discountid, eventid })
    setId(0)
    setName("")
    setPrice(0)
    setCategoryid(0)
    setDiscountid(0)
    setEventid(0)
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(() => (async () => setValidCreate(
    name !== "" &&
    price > 0 &&
    categoryid > 0 &&
    eventid > 0 &&
    await db.Events.findOne(eventid) !== undefined &&
    await db.Categories.findOne(categoryid) !== undefined &&
    (await db.Discounts.findOne(discountid) !== undefined)
  ))(), [name, price, categoryid, discountid, eventid])


  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    id > 0 &&
    name !== "" &&
    price > 0 &&
    categoryid > 0 &&
    eventid > 0 &&
    await db.Products.findOne(id) !== undefined &&
    await db.Events.findOne(eventid) !== undefined &&
    await db.Categories.findOne(categoryid) !== undefined &&
    (await db.Discounts.findOne(discountid) !== undefined)
  ))(), [id, name, price, categoryid, discountid, eventid])
  console.log(category);
  return (
    <div>
      <h1>Products</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Category type</th>
            <th>Discount code</th>
            <th>Event name</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
        {
              user.role === "Admin" ?
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setName(event.target.value)} placeholder="Name" value={name} />
            </td>
            <td>
              <Form.Control size="sm" type="number" onChange={event => setPrice(1 * event.target.value)} placeholder="Price" value={price} />
            </td>
            <td>
              <Form.Control as="select" onChange={event => setCategoryid(1 * event.target.value)} placeholder="Category type" value={categoryid}>
                <option value={0} key={0}>Select a category</option>
                {
                  category.map(event =>
                    <option value={event.id} key={event.id}>{event.type}</option>
                  )
                }
              </Form.Control>
            </td>
            <td>
              <Form.Control as="select" onChange={event => setDiscountid(1 * event.target.value)} placeholder="Discount code" value={discountid}>
                <option value={0} key={0}>Select an discount code</option>
                {
                  discount.map(event =>
                    <option value={event.id} key={event.id}>{event.code}</option>
                  )
                }
              </Form.Control>
            </td>
            <td>
              <Form.Control as="select" onChange={event => setEventid(1 * event.target.value)} placeholder="Event id" value={eventid}>
                <option value={0} key={0}>Select an event</option>
                {
                  events.map(event =>
                    <option value={event.id} key={event.id}>{event.name}</option>
                  )
                }
              </Form.Control>
            </td>
            
                <td>
                  <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
                  <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
                </td> 
          </tr>
          : null
        }
          {
            products.map(product =>
              <Product key={product.id} product={product} category={category} events={events} discount={discount} user={user} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}