import React, { useEffect, useState } from 'react'
import db from '../../../../db'
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";

function Product({ product, user, edit, remove }) {

  const [validRemove, setValidRemove] = useState(false)
  useEffect(() => (async () => setValidRemove(
    (await db.Cartitems.findByProductid(product.id)).length === 0
  ))(), [product])


  const [event, setEvents] = useState([])
  useEffect(() => (async () => setEvents(await db.Events.findOne(product.eventid)))(), [product.eventid])

  const [discount, setDiscount] = useState([])
  useEffect(() => (async () => setDiscount(await db.Discounts.findOne(product.discountid)))(), [product.discountid])

  const [category, setCategory] = useState([])
  useEffect(() => (async () => setCategory(await db.Categories.findOne(product.categoryid)))(), [product.categoryid])

  return (
    <tr>
      <td>{product.name}</td>
      <td>{product.price}</td>
      <td>{category.type}</td>
      <td>{discount.code}</td>
      <td>{event.name}</td>
      <td>
        {user.role === "Admin" ? <Button size="sm" variant="light" onClick={() => remove(product.id)} disabled={!validRemove}>X</Button> : null}
        {user.role === "Admin" ? <Button size="sm" variant="light" onClick={() => edit(product.id)}>Edit</Button> : null}
        {user.role === "Admin" ? <Button size="sm" variant="link" as={Link} to={`/productdetail/${product.id}`} product={product}>Details</Button> : null}
      </td>

    </tr>
  )
}


export default Product;
