import React, { useState, useEffect } from 'react'
import 'bootswatch/dist/darkly/bootstrap.min.css'
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import NavDropdown from 'react-bootstrap/NavDropdown'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom"
import Authenticate from './starter/public/Authenticate'
import Home from './starter/public/Home'
import Profile from './starter/user/Profile'
import Logout from './starter/user/Logout'
import UserContext from './UserContext'
import db from './db';

import PublicProductDetail from './starter/public/ProductDetail'
import AdminProductDetail from './starter/user/admin/Product/ProductDetail'
import SearchProductsByName from './starter/public/Search/SearchProductsByName'
import Products from './starter/user/admin/Product/Products'
import Categories from './60087621Mahmoud/Categories'
import Discounts from './60087621Mahmoud/Discounts'
import Bookmarks from './60087621Mahmoud/Bookmarks'
import Ratings from './60087621Mahmoud/Ratings'

import Events from './60095877turki/admin/Events'
import Carts from './60095877turki/Cart/Carts'
import CartItems from './60095877turki/Cart/CartItems'
import Mycarts from './60095877turki/customer/Mycarts'
import MycartItems from './60095877turki/customer/MycartItems'
import BuyProduct from './starter/public/BuyProduct'

import ContactUs from './60095068_Syeda/public/ContactUs'
import Sponsor from './60095068_Syeda/public/Sponsor'
import Faq from './60095068_Syeda/public/Faq'

import Plots from './60095877turki/admin/Plots'
import FoodCompanies from './60095877turki/admin/FoodCompanies'
import FoodEventPlots from './60095877turki/admin/FoodEventPlots'
import { CarouselItem } from 'react-bootstrap';
import PopularSearches from './60095068_Syeda/public/Search/PopularSearches'

export default function App() {

    const [jwtUser, setJwtUser] = useState(db.getJwtUser())
    const [user, setUser] = useState(null)

    useEffect(() => (async () => {
        db.setJwtUser(jwtUser)
        let user = null
        if (jwtUser) {
            user = await db.Users.findOne(jwtUser.username)
            if (!user) {
                await db.Users.create(users => { }, { id: jwtUser.username, name: "", role: "Customer", picture: '/images/UsersPictureDefault.png' })
                user = await db.Users.findOne(jwtUser.username)
            }
        }
        setUser(user)
    })(), [jwtUser])


    const cartss = async () => {

        const cart = await db.Carts.findCartByUseridAndStatus(user.id, "Unpaid")
        console.log(user.id);

        if (cart.length < 0) {
            await db.Carts.create(() => { }, { status: "paid", userid: user.id, totalprice: 0 })
        }

        return user.id
    }

    const isPublic = () => user === null
    const isLoggedIn = () => user !== null
    const isAdmin = () => user?.role === "Admin"
    const isCustomer = () => user?.role === "Customer"
    const isSupport = () => user?.role === "Support"
    const isCompany = () => user?.role === "Company-Rep"

    console.log(user, isPublic(), isLoggedIn(), isCustomer(), isAdmin(), isSupport())

    return (
        <UserContext.Provider value={{ user }}>
            <Router>
                <div className="container">
                    <Navbar bg="primary" variant="dark" expand="sm">
                        <Navbar.Brand as={Link} to="/">Home</Navbar.Brand>
                        <Navbar.Toggle aria-controls="basic-navbar-nav" />
                        <Navbar.Collapse id="basic-navbar-nav">
                        <Navbar.Brand as={Link} to="/sponsor">Sponsors And Partners</Navbar.Brand>
                        <Navbar.Brand as={Link} to="/faq">FAQ</Navbar.Brand>
                        <Navbar.Brand as={Link} to="/contactus">Contact Us</Navbar.Brand>

                            <Nav className="mr-auto">
                                {
                                    isPublic() &&
                                    <NavDropdown title="Search" id="basic-nav-dropdown">
                                        <NavDropdown.Item as={Link} to="/searchproductsbyname">Search Products by Name</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/popularsearches">Popular Searches</NavDropdown.Item>
                                    </NavDropdown>
                                }
                                {
                                    isCustomer() &&
                                    <>
                                        <Nav.Link as={Link} to="/profile">Profile</Nav.Link>
                                    </>
                                }
                                {
                                    isCompany() &&
                                    <>
                                        <Nav.Link as={Link} to="/">Company stuff</Nav.Link>
                                        <Nav.Link as={Link} to="/profile">Profile</Nav.Link>
                                    </>
                                }
                                {
                                    isSupport() &&
                                    <>
                                        <Nav.Link as={Link} to="/">Support Stuff</Nav.Link>
                                    </>
                                }
                                {
                                    isAdmin() &&
                                    <NavDropdown title="Pages" id="basic-nav-dropdown">
                                        <NavDropdown.Item as={Link} to="/products">Products</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/events">Events</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/carts">Carts</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/plots">Plots</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/foodcompanies">Food Companies</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/foodeventplots">Food event plots</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/products">Products</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/bookmarks">Bookmarks</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/categories">Categories</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/discounts">Discounts</NavDropdown.Item>
                                        <NavDropdown.Item as={Link} to="/ratings">Ratings</NavDropdown.Item>
                                    </NavDropdown>
                                }
                            </Nav>
                        </Navbar.Collapse>
                        <Nav className="mr-auto navbar-right">
                            {
                                isPublic()
                                &&
                                <>
                                    <Nav.Link as={Link} to="/register">Register</Nav.Link>
                                    <Nav.Link as={Link} to="/login">Login</Nav.Link>
                                </>
                            }
                            {
                                isLoggedIn()
                                &&
                                <Nav.Link as={Link} to="/logout">Logout</Nav.Link>
                            }
                        </Nav>
                    </Navbar>

                    {
                        isPublic()
                        &&
                        <Switch>
                            <Route path="/register">
                                <Authenticate type="Register" set={setJwtUser} />
                            </Route>
                            <Route path="/login">
                                <Authenticate type="Login" set={setJwtUser} />
                            </Route>
                            <Route path="/productdetail/:id">
                                <PublicProductDetail />
                            </Route>
                            <Route path="/sponsordetail/:id">
                                <PublicProductDetail />
                            </Route>
                            <Route path="/sponsor">
                                <Sponsor />
                            </Route>
                             <Route path="/faq">
                                <Faq />
                            </Route>    
                            <Route path="/contactus">
                                <ContactUs />
                            </Route>    
                            <Route path="/searchproductsbyname">
                                <SearchProductsByName />
                            </Route>
                            <Route path="/popularsearches">
                                <PopularSearches />
                            </Route>
                            <Route path="/plots">
                                <Plots user={user}/>
                            </Route>
                            <Route path="/">
                                <Home />
                            </Route>
                        </Switch>
                    }
                    {
                        isLoggedIn()
                        &&
                        <Switch>
                            <Route path="/logout">
                                <Logout set={setJwtUser} />
                            </Route>
                        </Switch>
                    }
                    {
                        isCustomer()
                        &&
                        <Switch>
                            <Route path="/profile">
                                <Profile set={setUser} />
                            </Route>
                            <Route path={`/mycart/${user.id}`}>
                                <Mycarts user={user}/>
                            </Route>
                            <Route path="/cartitems/:id">
                                <MycartItems user={user}/>
                            </Route>
                            <Route path="/buyproduct/:id">
                                <BuyProduct user={user}/>
                            </Route>
                            <Route path="/">
                                <Home />
                            </Route>
                        </Switch>
                    }
                    {
                        isSupport()
                        &&
                        <Switch>
                            <Route path="/profile">
                                <Profile set={setUser} />
                            </Route>
                        </Switch>
                    }
                    {
                        isAdmin()
                        &&
                        <Switch>
                            <Route path="/productdetail/:id">
                                <AdminProductDetail user={user}/>
                            </Route>
                            <Route path="/cartitems/:id">
                                <CartItems user={user}/>
                            </Route>
                            <Route path="/foodcompanies">
                                <FoodCompanies user={user} />
                            </Route>
                            <Route path="/foodeventplots">
                                <FoodEventPlots user={user}/>
                            </Route>
                            <Route path="/products">
                                <Products user={user}/>
                            </Route>
                            <Route path="/events">
                                <Events user={user}/>
                            </Route>
                            <Route path="/plots">
                                <Plots user={user}/>
                            </Route>
                            <Route path="/carts">
                                <Carts user={user}/>
                            </Route>
                            <Route path="/categories">
                                <Categories user={user}/>
                            </Route>
                            <Route path="/discounts">
                                <Discounts user={user}/>
                            </Route>
                            <Route path="/bookmarks">
                                <Bookmarks user={user}/>
                            </Route>
                            <Route path="/ratings">
                                <Ratings user={user} />
                            </Route>
                        </Switch>
                    }
                </div>
            </Router>
        </UserContext.Provider >
    )
}