import React, { useEffect, useState } from 'react'
import db from '../../../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Sponsor from './Sponsor'

export default function Sponsors() {

  const [sponsors, setSponsors] = useState([])
  const [id, setId] = useState(0)
  const [type, setType] = useState("")
  const [venueaddress, setVenueaddress] = useState("")
  const [contactname, setContactname] = useState("")
  const [venuename, setVenuename] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")

  useEffect(() => (async () => setSponsors(await db.SponsorPartners.findAll()))(), [])

  const create = async () => {
    await db.SponsorPartners.create(setSponsors, { type, venueaddress, contactname, venuename, email, phone })
    setId(0)
    setType("")
    setVenueaddress("")
    setContactname("")
    setVenuename("")
    setEmail("")
    setPhone("")
  }

  const remove = async id => await db.SponsorPartners.remove(setSponsors, id)

  const edit = async id => {
    const sponsor = await db.SponsorPartners.findOne(id)
    setId(sponsor.id)
    setType(sponsor.type)
    setVenueaddress(sponsor.venueaddress)
    setContactname(sponsor.contactname)
    setVenuename(sponsor.venuename)
    setEmail(sponsor.email)
    setPhone(sponsor.phone)
  }

  // update is step 2
  const update = async () => {
    await db.SponsorPartners.update(setSponsors, { id, type, venueaddress, contactname, venuename, email, phone })
    setId(0)
    setType("")
    setVenueaddress("")
    setContactname("")
    setVenuename("")
    setEmail("")
    setPhone("")
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(() => setValidCreate(
    type !== "" &&
    venueaddress !== "" &&
    contactname !== "" &&
    venuename !== "" &&
    email !== "" &&
    phone !== ""
  ), [type, venueaddress, contactname, venuename, email, phone])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    id > 0 &&
    type !== "" &&
    venueaddress !== "" &&
    contactname !== "" &&
    venuename !== "" &&
    email !== "" &&
    phone !== "" &&
    await db.SponsorPartners.findOne(id) !== undefined
  ))(), [id, type, venueaddress, contactname, venuename, email, phone])

  return (
    <div>
      <h1>Sponsors</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Type</th>
            <th>Venue Address</th>
            <th>Contactname</th>
            <th>Venue Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setType(event.target.value)} placeholder="Type" value={type} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setVenueaddress(event.target.value)} placeholder="Venue address" value={venueaddress} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setContactname(event.target.value)} placeholder="Contact name" value={contactname} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setVenuename(event.target.value)} placeholder="Venue name" value={venuename} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setEmail(event.target.value)} placeholder="Email" value={email} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setPhone(event.target.value)} placeholder="Phone" value={phone} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>
          {
            sponsors.map(sponsor =>
              <Sponsor key={sponsor.id} sponsor={sponsor} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}