import React, { useEffect, useState } from 'react'
import db from '../../../../db'
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";

function Sponsor({ sponsor, edit, remove }) {

  const [validRemove, setValidRemove] = useState(false)
  // useEffect(() => (async () => setValidRemove(
  //   (await db.SponsorPartners.findBySponsorid(sponsor.id)).length === 0
  // ))(), [sponsor])

  return (
    <tr>
      <td>{sponsor.type}</td>
                <td>{sponsor.venueaddress}</td>
                <td>{sponsor.contactname}</td>
                <td>{sponsor.venuename}</td>
                <td>{sponsor.email}</td>
                <td>{sponsor.phone}</td>
      <td>
        <Button size="sm" variant="light" onClick={() => remove(sponsor.id)} disabled={!validRemove}>X</Button>
        <Button size="sm" variant="light" onClick={() => edit(sponsor.id)}>Edit</Button>
        <Button size="sm" variant="link" as={Link} to={`/sponsordetail/${sponsor.id}`}>Details</Button>
      </td>
    </tr>
  )
}

export default Sponsor;
