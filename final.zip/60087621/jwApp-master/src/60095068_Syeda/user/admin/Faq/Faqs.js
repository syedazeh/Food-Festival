import React, { useEffect, useState } from 'react'
import db from '../../../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Faq from './Faq'

export default function Faqs() {

  const [faqs, setFaqs] = useState([])
  const [id, setId] = useState(0)
  const [question, setQuestion] = useState("")
  const [answer, setAnswer] = useState("")

  useEffect(() => (async () => setFaqs(await db.Faqs.findAll()))(), [])

  const create = async () => {
    await db.Faqs.create(setFaqs, { question, answer })
    setId(0)
    setQuestion("")
    setAnswer("")
  }

  const remove = async id => await db.Faqs.remove(setFaqs, id)

  const edit = async id => {
    const faq = await db.Faqs.findOne(id)
    setId(faq.id)
    setQuestion(faq.question)
    setAnswer(faq.answer)
  }

  // update is step 2
  const update = async () => {
    await db.Faqs.update(setFaqs, { id, question, answer })
    setId(0)
    setQuestion("")
    setAnswer("")
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(() => setValidCreate(
    question !== "" &&
    answer !== ""
  ), [question, answer])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    question !== "" &&
    id > 0 &&
    answer !== "" &&
    await db.Faqs.findOne(id) !== undefined
  ))(), [id, question, answer])

  return (
    <div>
      <h1>Faqs</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Question</th>
            <th>Answer</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setQuestion(event.target.value)} placeholder="Question" value={question} />
            </td>
            <td>
              <Form.Control size="sm" type="number" onChange={event => setAnswer(event.target.value)} placeholder="Answer" value={answer} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>
          {
            faqs.map(faq =>
              <Faq key={faq.id} faq={faq} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >

    
  );
}