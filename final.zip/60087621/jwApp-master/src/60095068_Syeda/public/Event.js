import React from 'react'
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";

export default function Event({ event }) {

  return (
    <tr>
      <td>{event.name}</td>
      <td>{event.type}</td>
      <td>
        <Button size="sm" variant="link" as={Link} variant="light" to={`/eventdetail/${event.id}`}>Details</Button>
      </td>
    </tr>
  )
}