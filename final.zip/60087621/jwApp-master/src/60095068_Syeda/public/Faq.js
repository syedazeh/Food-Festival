import React, { useEffect, useState } from 'react'
import db from '../../db'
import Form from 'react-bootstrap/Form';
import Accordion from 'react-bootstrap/Accordion'
import Card from 'react-bootstrap/Card'
import faqimage from '../../images/faq.jpeg';
import Alert from 'react-bootstrap/Alert'

export default function Faqs() {

  const [faqs, setfaq] = useState([])
  const [question, setName] = useState("")
  useEffect(() => (async () => setfaq(await db.Faqs.findByNameContaining(question)))(), [question])
  

  return (
    <>
    
    <img src = {faqimage} alt = "Contact Us" width="100%"></img>
    <br></br>
    <br></br>
      <h1>FAQs</h1>
      {/* <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
              <th>Question</th>
              <th>Answer</th>
          </tr>
        </thead>
        <tbody>
          {
            faqs.map(faq => 
              <tr key={faq.id}>
                <td>{faq.question}</td>
                <td>{faq.answer}</td>
              </tr> )
          }
        </tbody>
      </Table> */}

<h1>Search Faq by Question</h1>
<Form.Control size="sm" type="text" onChange={event => setName(event.target.value)} placeholder="question" value={question} />

      <div>
        {
          faqs.map(faq => 
            <Accordion>
            <Accordion.Toggle variant="link" eventKey="0">
              {faq.question}
            </Accordion.Toggle>
          <Accordion.Collapse eventKey="0">
            <Card.Body>{faq.answer}</Card.Body>
          </Accordion.Collapse>
      </Accordion>
            )
        }

      </div>

      <br></br>
    <br></br>
  {/* <Alert variant="success">
    <p style = {{fontSize: '2em'}}>
    Is there a query that has not been answered yet? Contact our Food Festival Team 
    <Alert.Link href='./ContactUs.js'> HERE</Alert.Link>
    </p>
  </Alert> */}
    </>
  )
}



