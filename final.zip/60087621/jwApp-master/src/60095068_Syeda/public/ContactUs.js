import React from 'react'
import contactusimage from '../../images/contactus.jpeg';

export default function ContactUs() {

  return (
    <>
    <img src = {contactusimage} alt = "Contact Us" width="100%"></img>
    <br></br>
    <br></br>
    <p>For Sponsorship, Restaurant and Exhibitor enquiries, please contact:</p>
<br></br>
      <p>Farah Aboudia</p>
<br></br>
     <p> Event Director</p>
<br></br>
      <p>E: f.aboudia@foodfestival.com</p>
<br></br>
      <p>Syeda Zehra</p>
<br></br>
      <p>Sales Manager</p>
<br></br>
      <p>E: s.zehra@foodfestival.com</p>
<br></br>
      <p>If you have any general enquiries, please visit our FAQ page to see if your question has already been answered or else please contact the Food Festival Team.
      </p>
    </>
  )
}