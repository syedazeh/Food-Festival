import React, { useEffect, useState } from 'react'
import db from '../../db'
import Table from 'react-bootstrap/Table';
import Product from '../public/Product'
import Alert from 'react-bootstrap/Alert'
import Card from 'react-bootstrap/Card'
import Button from 'react-bootstrap/Button'
import Form from 'react-bootstrap/Form'
import { Link } from "react-router-dom";
import Accordion from 'react-bootstrap/Accordion'
import {render} from 'react-dom';
import ReactDOM from 'react-dom';
import Sponsor from './Sponsor';
var path = '../../images'
// import '../../App.css'

export default function Home() {

    const [products, setProducts] = useState([])

  useEffect(() => (async () => setProducts(await db.Products.findAll()))(), [])

  const [events, setEvents] = useState([])

  useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])

  return (
    <>
    <div class="ModuleVideoEmbedded-module--aspectWrapper---thoP">
  <video autoplay="" playsinline="" loop="" muted="" controls="" width="100%">
    <source src="//videos.ctfassets.net/2h1qowfuxkq7/6byY4lJKmVRhajkUYWLedF/9d995ddfd941bfd3ef72205378f792c0/GENERIC_ENG_NEW.mp4" type="video/mp4">
      </source>
    </video>
</div>

<div>
  <p></p>
</div>

    <br></br>
    <br></br>
  <Alert variant="success">
    <p style = {{fontSize: '2em'}}>
    Want to buy a plot for our food festival?
    <Alert.Link href='#'> Click here!</Alert.Link>
    </p>
  </Alert>


    <h1>TICKETS</h1>

{
  products.map(product => 
    <Card style={{ width: '18rem', height: '22rem' , float:'left' , margin: '10px 30px 30px 10px'}}>
    <Card.Body>
      <Card.Title>{product.name}</Card.Title>
      <Card.Subtitle className="mb-2 text-muted">{product.price} QR</Card.Subtitle>
      <Card.Text>
        {
          product.name == 'VIP Ticket' ? 
          <>
          <p><b>Each Ticket Inlcudes</b></p>
          <p>
          Festival Entry <br></br>
          Access To All Features <br></br>
          Exclusive VIP Lounge Access 
          </p>
          </>
          : (product.name == 'Gold Ticket' 
          ? 
          <>
          <p><b>Each Ticket Inlcudes</b></p>
          <p>
          Festival Entry <br></br>
          Access To All Features <br></br>
          Exclusive VIP Lounge Access<br></br>
          Be able to cook alongside chefs in the Live Cooking Theatre
          </p>
          </>
          : 
          <>
          <p><b>Each Ticket Inlcudes</b></p>
          <p>Standard Festival Entry</p>
          </>
          )
        }
      </Card.Text>
      <Button size="sm" variant="link" variant="dark" as={Link} to={`/productdetail/${product.id}`}>Detail</Button>
      <br></br>
      <br></br>
      <Button size="sm" variant="link" variant="dark" as={Link}>Buy</Button>
    </Card.Body>
    </Card>  
  )}

<h1>EVENTS</h1>

<div>
 {
    events.map(event => 
      <div>
      <Card style={{ width: '18rem', height: '22rem', float:'left' , margin: '10px 30px 30px 10px'}}>
      <Card.Img variant="top" src={`../../images/${event.name}.jpeg`}  style = {{width: '100%', height: '200px'}}/>
      <Card.Body>
        <Card.Title>{event.name}</Card.Title>
        <Card.Text>
          {event.type}
        </Card.Text>
        <Button size="sm" variant="link" variant="dark" as={Link} to={`/eventdetail/${event.id}`}>Details</Button>
      </Card.Body>
    </Card>
    </div>)
  }
</div>

    </>
  )
}

