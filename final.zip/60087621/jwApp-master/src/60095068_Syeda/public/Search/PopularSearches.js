import React, { useState, useEffect } from 'react'
import db from '../../../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Event from '../../public/Event'

export default function PopularSearches() {

    const [events, setEvents] = useState([])
    useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])

    const [popular, setPopular] = useState([])
    var [title, setTitle] = useState("")
    
    useEffect(() => (async () => setPopular(await db.PopularSearches.findAll()))(), [])
    
    var sortPopular = popular.sort((a,b) => b.frequency - a.frequency);
    console.log(popular)
    
    console.log(title)

    const search = async () => {

        const find = popular.find(item => title == item.title)
        if (find === undefined) {
          await db.PopularSearches.create(setPopular, {title, frequency:1 }) 
        }
        else {
          await db.PopularSearches.update(setPopular, { id:find.id, title, frequency: find.frequency+1 })
        }
        setTitle("")
        setPopular(await db.PopularSearches.findAll())
        setEvents(await db.Events.findByNameContaining(title))
      }

    return (
        <>
            <h1>Search Events by Name</h1>
            <input list="searches" name="myList" onChange={event => setTitle(event.target.value)} placeholder="Name" value={title}/>    
            <datalist id="searches">
            {sortPopular[0] === undefined ? null : <option value = {sortPopular[0].title}/>}
            {sortPopular[1] === undefined ? null : <option value = {sortPopular[1].title}/>}
            {sortPopular[2] === undefined ? null : <option value = {sortPopular[2].title}/>}
            </datalist>
            <Button size="sm" variant="light" onClick={search}>Search</Button>
            
            <Table striped bordered hover variant="dark" size="sm">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        events.map(event => <Event key={event.id} event={event} />)
                    }
                </tbody>
            </Table>
        </>
    )
}
