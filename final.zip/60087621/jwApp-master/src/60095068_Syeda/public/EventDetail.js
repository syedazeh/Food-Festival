import React, { useEffect, useState } from 'react'
import db from '../../db'
import {
  useParams
} from "react-router-dom";

export default function EventDetail() {

  const { id: stringId } = useParams();
  const id = 1 * stringId

  const [event, setEvent] = useState(null)
  useEffect(() => (async () => setEvent(await db.Events.findOne(id)))(), [id])

  return (
    event
    &&
    <>
      <h1>Event</h1>
      <dl className="row">
        <dt className="col-sm-3">Name</dt>
        <dd className="col-sm-9">{event.name}</dd>
        <dt className="col-sm-3">Type</dt>
        <dd className="col-sm-9">{event.type}</dd>
      </dl>
    </>
  )
}