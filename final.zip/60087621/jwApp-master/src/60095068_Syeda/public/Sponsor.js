import React, { useState, useEffect } from 'react'
import Button from 'react-bootstrap/Button';
import { Link } from "react-router-dom";
import Card from 'react-bootstrap/Card'
import db from '../../db'
import Form from 'react-bootstrap/Form';

export default function Sponsor({sponsor}) {

  const [name, setName] = useState("")
  const [sponsors, setSponsors] = useState([])
  useEffect(() => (async () => setSponsors(await db.SponsorPartners.findByNameContaining(name)))(), [name])

console.log(sponsor)
return (
  <>
              <h1>Search Sponsors by Name</h1>
            <Form.Control size="sm" type="text" onChange={event => setName(event.target.value)} placeholder="Name" value={name} />
{
  sponsors.map(sponsor => 
<Card style={{ width: '18rem' }}>
  <Card.Img variant="top" src={`../../images/${sponsor.contactname}.jpeg`} />
  <Card.Body>
    <Card.Title>{sponsor.contactname}</Card.Title>
    <Button size="sm" variant="link" as={Link} to={`/sponsordetail/${sponsor.id}`}>Details</Button>
  </Card.Body>
</Card>
)}
</>
)
}

