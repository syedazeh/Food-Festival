import React, { useEffect, useState } from 'react'
import db from '../../db'
import {
  useParams
} from "react-router-dom";

export default function SponsorDetail() {

  const { id: stringId } = useParams();
  const id = 1 * stringId

  const [sponsor, setSponsor] = useState(null)
  useEffect(() => (async () => setSponsor(await db.SponsorPartners.findOne(id)))(), [id])

  return (
    sponsor
    &&
    <>
      <h1>Sponsor</h1>
      <dl className="row">
        <dt className="col-sm-3">Type</dt>
        <dd className="col-sm-9">{sponsor.type}</dd>
        <dt className="col-sm-3">Venu Address</dt>
        <dd className="col-sm-9">{sponsor.venueaddress}</dd>
        <dt className="col-sm-3">Contact Name</dt>
        <dd className="col-sm-9">{sponsor.contactname}</dd>
        <dt className="col-sm-3">Venu Name</dt>
        <dd className="col-sm-9">{sponsor.venuename}</dd>
        <dt className="col-sm-3">Email</dt>
        <dd className="col-sm-9">{sponsor.email}</dd>
        <dt className="col-sm-3">Phone</dt>
        <dd className="col-sm-9">{sponsor.phone}</dd>
      </dl>
    </>
  )
}