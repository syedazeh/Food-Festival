import React, { useEffect, useState } from 'react'
import db from '../db'
import Button from 'react-bootstrap/Button';

function Discount({ discounts, edit, remove }) {

  
  const [validRemove, setValidRemove] = useState(false)
  useEffect(() => (async () => setValidRemove(
    (await db.Products.findByDiscountid(discounts.id)).length === 0
  ))(), [discounts])

  return (
    <tr>
      <td>{discounts.name}</td>
      <td>{discounts.code}</td>
      <td>{discounts.validity.toDateString()}</td>
      <td>
        <Button size="sm" variant="light" onClick={() => remove(discounts.id)} disabled={!validRemove}>X</Button>
        <Button size="sm" variant="light" onClick={() => edit(discounts.id)}>Edit</Button>
      </td>
    </tr>
  )
}

export default Discount;