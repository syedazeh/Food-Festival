import React, { useEffect, useState } from 'react'
import db from '../db'
import Table from 'react-bootstrap/Table';
// import Button from 'react-bootstrap/Button';
// import Form from 'react-bootstrap/Form';
import Bookmark from './Bookmark'

export default function Bookmarks() {

  const [bookmark, setBookmarks] = useState([])
  const [events, setEvents] = useState([])
  const [users, setUsers] = useState([])

  const [id, setId] = useState(0)
  const [eventid, setEventid] = useState(0)
  const [userid, setUserid] = useState("")
  const [type, setType] = useState("")



  useEffect(() => (async () => setBookmarks(await db.Bookmarks.findAll()))(), [])
  // useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])
  // useEffect(() => (async () => setUsers(await db.Users.findAll()))(), [])

  // const create = async () => {
  //   await db.Bookmarks.create(setBookmarks, { eventid, userid, type })
  //   setId(0)
  //   setEventid(0)
  //   setUserid("")
  //   setType("")
  // }

  const remove = async id => await db.Bookmarks.remove(setBookmarks, id)

  // const edit = async id => {
  //   const bookmark = await db.Bookmarks.findOne(id)
  //   setId(bookmark.id)
  //   setEventid(bookmark.eventid)
  //   setUserid(bookmark.userid)
  //   setType(bookmark.type)
  // }

  // update is step 2
  // const update = async () => {
  //   await db.Bookmarks.update(setBookmarks, { id, eventid, userid, type })
  //   setId(0)
  //   setEventid(0)
  //   setUserid("")
  //   setType("")
  // }

  // const [validCreate, setValidCreate] = useState(false)
  // useEffect(() => (async () => setValidCreate(
  //   eventid !== 0 &&
  //   userid !== "" &&
  //   type !== "" &&
  //   (await db.Users.findOne(userid)) !== undefined &&
  //   (await db.Events.findOne(eventid)) !== undefined &&
  //   (await db.Bookmarks.findOne(id)) !== undefined

  // ))(), [userid, eventid, type])

  // const [validUpdate, setValidUpdate] = useState(false)
  // useEffect(() => (async () => setValidUpdate(
  //   eventid !== 0 &&
  //   userid !== "" &&
  //   type !== "" &&
  //   (await db.Users.findOne(userid)) !== undefined &&
  //   (await db.Events.findOne(eventid)) !== undefined &&
  //   (await db.Bookmarks.findOne(id)) !== undefined
  // ))(), [id, userid, eventid, type])

  return (
    <div>
      <h1>Bookmarks</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Event Name</th>
            <th>Client</th>
            <th>Event type</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
          {/* <tr>
            <td>
              <Form.Control as="select" onChange={event => setEventid(event.target.value)} placeholder="Event id" value={eventid}>
                <option value={0} key={0}>Select an event</option>
                {
                  events.map(event => 
                    <option value={event.id} key={event.id}>{event.name}</option>

                    )
                }
              </Form.Control>
            </td>
            <td>
              <Form.Control as="select" onChange={event => setUserid(event.target.value)} placeholder="Client" value={userid}>
                <option value={0} key={0}>Select a user</option>
                {
                  users.map(user => 
                    <option value={user.id} key={user.id}>{user.id}</option>

                    )
                }
              </Form.Control>
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={event => setType(event.target.value)} placeholder="Type" value={type} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr> */}
          {
            bookmark.map(bookmark =>
              <Bookmark key={bookmark.id} bookmark={bookmark} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}