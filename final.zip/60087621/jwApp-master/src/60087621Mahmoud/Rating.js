import React, { useEffect, useState } from 'react'
import db from '../db'
import Button from 'react-bootstrap/Button';

function Rating({ user, rating, remove }) {

  const [validRemove, setValidRemove] = useState(false)
  useEffect(() => (async () => setValidRemove(
    (await db.Events.findOne(rating.eventid)) !== undefined &&
    (await db.Users.findOne(rating.userid)) !== undefined
  ))(), [rating])

  const [event, setEvents] = useState([])
  useEffect(() => (async () => setEvents(await db.Events.findOne(rating.eventid)))(), [rating.eventid])


  return (
    <tr>
      <td>{event.name}</td>
      <td>{rating.userid}</td>
      <td>{rating.comment}</td>
      <td>{rating.date.toDateString()}</td>
      <td>{rating.stars}</td>
      <td>
        {
        user.role === "Admin"?
          <Button size="sm" variant="light" onClick={() => remove(rating.id)} disabled={!validRemove}>X</Button>:null
  }
      </td>
    </tr>
  )
}

export default Rating;