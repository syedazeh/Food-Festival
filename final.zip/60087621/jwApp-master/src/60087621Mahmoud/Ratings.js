import React, { useEffect, useState } from 'react'
import db from '../db'
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Rating from './Rating'

export default function Ratings({user}) {

    const [rating, setRatings] = useState([])
    const [events, setEvents] = useState([])
    const [users, setUsers] = useState([])

    const [id, setId] = useState(0)
    const [eventid, setEventid] = useState(0)
    const [userid, setUserid] = useState(user.id)
    const [comment, setComment] = useState("")
    const [date, setDate] = useState(new Date())
    const [stars, setStars] = useState("")



    useEffect(() => (async () => setRatings(await db.Ratings.findAll()))(), [])
    useEffect(() => (async () => setEvents(await db.Events.findAll()))(), [])
    useEffect(() => (async () => setUsers(await db.Users.findOne(userid)))(), [userid])

    const create = async () => {
        await db.Ratings.create(setRatings, { userid, eventid, comment, date, stars })
        setId(0)
        setUserid("")
        setEventid(0)
        setComment("")
        setDate(new Date())
        setStars("")
    }

    const remove = async id => await db.Ratings.remove(setRatings, id)

    // const edit = async id => {
    //     const rating = await db.Ratings.findOne(id)
    //     setId(rating.id)
    //     setEventid(rating.eventid)
    //     setUserid(rating.userid)
    //     setComment(rating.comment)
    //     setDate(rating.date)
    //     setStars(rating.stars)
    // }

    //   update is step 2
    // const update = async () => {
    //     await db.Ratings.update(setRatings, { id, eventid, userid, comment, date, stars })
    //     setId(0)
    //     setEventid(0)
    //     setUserid("")
    //     setComment("")
    //     setDate(new Date())
    //     setStars("")
    // }

    const [validCreate, setValidCreate] = useState(false)
    useEffect(() => (async () => setValidCreate(
        eventid > 0 &&
        userid !== "" &&
        comment !== "" &&
        stars >= 1 &&
        stars <= 5 &&
        await db.Events.findOne(eventid) !== undefined
    ))(), [userid, eventid, comment, date, stars])

    // const [validUpdate, setValidUpdate] = useState(false)
    // useEffect(() => (async () => setValidUpdate(
    //     eventid !== 0 &&
    //     userid !== "" &&
    //     comment !== "" &&
    //     stars >= 0 && stars <= 5 &&
    //     (await db.Users.findOne(userid)) !== undefined &&
    //     (await db.Events.findOne(eventid)) !== undefined &&
    //     (await db.Ratings.findOne(id)) !== undefined
    // ))(), [id, userid, eventid, comment, date, stars])

    
    return (
        <div>
            <h1>Ratings</h1>
            <Table striped bordered hover variant="dark" size="sm">
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Client</th>
                        <th>Comment</th>
                        <th>Date</th>
                        <th>Stars</th>
                        <th></th>

                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <Form.Control as="select" onChange={event => setEventid( 1 * event.target.value)} placeholder="Event id" value={eventid}>
                                <option value={0} key={0}>Select an event</option>
                                {
                                    events.map(event =>
                                        <option value={event.id} key={event.id}>{event.name}</option>

                                    )
                                }
                            </Form.Control>
                        </td>
                        <td>
                        <Form.Control size="sm" type="text" onChange={event => setUserid(event.target.value)} placeholder="User id" value={user.role} readOnly/>
                        </td>
                        <td>
                            <Form.Control size="sm" type="text" onChange={event => setComment(event.target.value)} placeholder="Comment" value={comment} />
                        </td>
                        <td>
                            <Form.Control size="sm" type="date" onChange={event => setDate(new Date(event.target.value))} placeholder="Date" value={new Date().toISOString().slice(0, 10)} readOnly/>
                        </td>
                        <td>
                            <Form.Control size="sm" type="text" onChange={event => setStars(event.target.value)} placeholder="Stars" value={stars} />
                        </td>
                        <td>
                            <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
                            {/* <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button> */}
                        </td>
                    </tr>
                    {
                        rating.map(rating =>
                            <Rating key={rating.id} rating={rating} user={user} remove={remove} />
                        )
                    }
                </tbody>
            </Table>
        </div >
    );
}