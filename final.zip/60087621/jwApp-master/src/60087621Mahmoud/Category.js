import React, { useEffect, useState } from 'react'
import db from '../db'
import Button from 'react-bootstrap/Button';

function Category({ categories, edit, remove }) {

  
  const [validRemove, setValidRemove] = useState(false)
  useEffect(() => (async () => setValidRemove(
    (await db.Products.findByCategoryid(categories.id)).length === 0
  ))(), [categories])

  return (
    <tr>
      <td>{categories.name}</td>
      <td>{categories.type}</td>
      <td>
        <Button size="sm" variant="light" onClick={() => remove(categories.id)} disabled={!validRemove}>X</Button>
        <Button size="sm" variant="light" onClick={() => edit(categories.id)}>Edit</Button>
      </td>
    </tr>
  )
}

export default Category;