import React, { useEffect, useState } from 'react'
import db from '../db';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Discount from './Discount'
export default function Discounts() {

  const [discounts, setDiscounts] = useState([])
  const [id, setId] = useState(0)
  const [name, setName] = useState("")
  const [code, setCode] = useState("")
  const [validity, setValidity] = useState(new Date())


  useEffect(() => (async () => setDiscounts(await db.Discounts.findAll()))(), [])

  const create = async () => {
    await db.Discounts.create(setDiscounts, {name, code, validity})
    setId(0)
    setName("")
    setCode("")
    setValidity(new Date())
  }

  const remove = async id => await db.Discounts.remove(setDiscounts, id)

  const edit = async id => {
    const discounts = await db.Discounts.findOne(id)
    setId(discounts.id)
    setName(discounts.name)
    setCode(discounts.code)
    setValidity(discounts.validity)
  }

  // update is step 2
  const update = async () => {
    await db.Discounts.update(setDiscounts, {id, name, code, validity})
    setId(0)
    setName("")
    setCode("")
    setValidity(new Date())
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(() => setValidCreate(
    name !== "" &&
    code !== "" &&
    validity >= new Date()
  ), [name, code, validity])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    id !== "" &&
    name !== "" &&
    code !== "" &&
    validity >= new Date() &&
    await db.Discounts.findByCode(code) !== undefined
  ))(), [id, name, code, validity])

  return (
    <div>
      <h1>Discounts</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Name</th>
            <th>Code</th>
            <th>Validity</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={discounts => setName(discounts.target.value)} placeholder="Name" value={name} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={discounts => setCode(discounts.target.value)} placeholder="Code" value={code} />
            </td>
            <td>
            <Form.Control size="sm" type="date" onChange={discounts => setValidity(new Date(discounts.target.value))} placeholder="validity" value={validity.toISOString().slice(0,10)} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>
          {
            discounts.map(discounts =>
              <Discount key={discounts.id} discounts={discounts} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}