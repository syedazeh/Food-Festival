import React, { useEffect, useState } from 'react'
import db from '../db'
import Button from 'react-bootstrap/Button';

function Bookmark({ bookmark, edit, remove }) {

  const [validRemove, setValidRemove] = useState(false)
  useEffect(() => (async () => setValidRemove(
    (await db.Events.findOne(bookmark.eventid)) !== undefined &&
    (await db.Users.findOne(bookmark.userid)) !== undefined
  ))(), [bookmark])

  const [event, setEvents] = useState([])
  useEffect(() => (async () => setEvents(await db.Events.findOne(bookmark.eventid)))(), [bookmark.eventid])


  return (
    <tr>
      <td>{event.name}</td>
      <td>{bookmark.userid}</td>
      <td>{event.type}</td>
      <td>
        <Button size="sm" variant="light" onClick={() => remove(bookmark.id)} disabled={!validRemove}>X</Button>
        {/* <Button size="sm" variant="light" onClick={() => edit(bookmark.id)}>Edit</Button> */}
      </td>
    </tr>
  )
}

export default Bookmark;