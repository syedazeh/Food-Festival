import React, { useEffect, useState } from 'react'
import db from '../db';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Category from './Category'
export default function Categories() {

  const [categories, setCategories] = useState([])
  const [id, setId] = useState(0)
  const [name, setName] = useState("")
  const [type, setType] = useState("")


  useEffect(() => (async () => setCategories(await db.Categories.findAll()))(), [])

  const create = async () => {
    await db.Categories.create(setCategories, {name, type})
    setId(0)
    setName("")
    setType("")
  }

  const remove = async id => await db.Categories.remove(setCategories, id)

  const edit = async id => {
    const categories = await db.Categories.findOne(id)
    setId(categories.id)
    setName(categories.name)
    setType(categories.type)
  }

  // update is step 2
  const update = async () => {
    await db.Categories.update(setCategories, {id, name, type})
    setId(0)
    setName("")
    setType("")
  }

  const [validCreate, setValidCreate] = useState(false)
  useEffect(() => setValidCreate(
    name !== "" &&
    type !== ""
  ), [id, name, type])

  const [validUpdate, setValidUpdate] = useState(false)
  useEffect(() => (async () => setValidUpdate(
    name !== "" &&
    type !== "" &&
    await db.Categories.findOne(id) !== undefined
  ))(), [id, name, type])

  return (
    <div>
      <h1>Categories</h1>
      <Table striped bordered hover variant="dark" size="sm">
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th></th>

          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <Form.Control size="sm" type="text" onChange={categories => setName(categories.target.value)} placeholder="Name" value={name} />
            </td>
            <td>
              <Form.Control size="sm" type="text" onChange={categories => setType(categories.target.value)} placeholder="Type" value={type} />
            </td>
            <td>
              <Button size="sm" variant="light" onClick={create} disabled={!validCreate}>Create</Button>
              <Button size="sm" variant="light" onClick={update} disabled={!validUpdate}>Update</Button>
            </td>
          </tr>
          {
            categories.map(categories =>
              <Category key={categories.id} categories={categories} edit={edit} remove={remove} />
            )
          }
        </tbody>
      </Table>
    </div >
  );
}